/**
 * Clase para probar excepciones, crear fichero y uso de fechas
 * Batiburrillo...
 */
package ficherofecha;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author melola
 */
public class FicheroFecha {

    static String pathLog = "OutFile.log";
    static PrintWriter out = null;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // 1. Crear un fichero de log
            crearFicheroLog();
            
            // 2. Escribir en el fichero de log
            escribirEnFicheroLog("Hola caracola!");
            
            escribirEnFicheroLog("OTRA FECHA:"+dameFecha("yyyy/MM/dd"));
                    
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } finally{
          out.close();
        }
        
        
    }
    
    /**
     * Método para crear el fichero de log
     * @throws FileNotFoundException 
     */
    private static void crearFicheroLog() throws FileNotFoundException{
        out = new PrintWriter(pathLog);
        out.print("["+dameFecha("dd/MM/yyyy HH:mm:ss ")+"] *** EMPEZANDO FICHERO LOG ****");
    } 
    
    private static void escribirEnFicheroLog(String msg){
        out.print("("+System.currentTimeMillis()+")");
        out.printf("Mi número %d\n", 8);
        out.println("Primera fecha: "+dameFechaByDefault());
        out.println("Este es el mensaje:"+msg);
        out.println("********************");
    }
    /**
     * Método para devolver fecha dependiendo del formato
     * @param formato
     * @return 
     */
    private static String dameFecha(String formato){
        DateTimeFormatter dft = DateTimeFormatter.ofPattern(formato);
        return dft.format(LocalDateTime.now());
    }
    
    /**
     * Método para devolver fecha completa con formato por defecto
     * @return 
     */
    private static String dameFechaByDefault(){
        SimpleDateFormat date = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
        return date.format(new Date());
    }
    
}
