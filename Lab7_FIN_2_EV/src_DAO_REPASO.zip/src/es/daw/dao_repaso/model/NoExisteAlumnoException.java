package es.daw.dao_repaso.model;

/**
 *
 * @author melola
 */
public class NoExisteAlumnoException extends Exception{
    
    private String dni,nombreClase;

    public NoExisteAlumnoException(String dni, String nombreClase) {
        this.dni = dni;
        this.nombreClase = nombreClase;
    }

    @Override
    public String getMessage() {
        return "EXCEPCIÓN: No existe el alumno con dni "+dni+" en la clase "+nombreClase;
    }
    
    
    
}
