package es.daw.dao_repaso.model;

import java.util.ArrayList;

/**
 *
 * @author melola
 */
public class Aula {

    private String curso, siglas, grado, centro;
    private ArrayList<Alumno> listaAlumnos;
    private ArrayList<NoExisteAlumnoException> excepciones;

    public Aula(String curso, String siglas, String grado, String centro) {
        this.curso = curso;
        this.siglas = siglas;
        this.grado = grado;
        this.centro = centro;
        this.listaAlumnos = new ArrayList<>();
        this.excepciones = new ArrayList<>();
    }

    public String getCurso() {
        return curso;
    }

    public String getSiglas() {
        return siglas;
    }

    public String getGrado() {
        return grado;
    }

    public String getCentro() {
        return centro;
    }

    // COSAS A TENER EN CUENTA CUANDO UTILIZO COLECCIONES....
    public void setListaAlumnos(ArrayList<Alumno> listaAlumnosOriginal) {
        // Para que no sea el mismo arraylist por referencia....
        ArrayList<Alumno> listaAlumnos = (ArrayList<Alumno>) listaAlumnosOriginal.clone();
        this.listaAlumnos = listaAlumnos;
    }

    public ArrayList<Alumno> getListaAlumnos() {
        // Devuelvo una copia arraylist para que no sea el mismo arraylist por referencia
        ArrayList<Alumno> listaAlumnosCopia = (ArrayList<Alumno>) listaAlumnos.clone();
        return listaAlumnosCopia;
    }
    
    /* SI NO TRABAJO CON LA LISTA DE ALUMNOS COMO COPIA
    public ArrayList<Alumno> getListaAlumnos() {
        return listaAlumnos;
    }

    public void setListaAlumnos(ArrayList<Alumno> listaAlumnos) {
        this.listaAlumnos = listaAlumnos;
    }
    */
    
    
    /**
     * Añadir alumno al aula
     * @param a 
     */
    public void addAlumno(Alumno a){
        listaAlumnos.add(a);
    }
    
    /**
     * Quitar alumno del aula por posición
     * @param index 
     */
    public void removeAlumno(int index){
        listaAlumnos.remove(index);
    }
    
    /**
     * Quitar alumno del aula
     * @param a 
     */
    public void removeAlumno(Alumno a){
        listaAlumnos.remove(a);
    }
   
    public Alumno buscarXDNI(String dni) throws NoExisteAlumnoException{
        
        //Pendiente de implementar
        // 1. Recorrer el arraylist de alumnos y buscar el alumno con dni 
        // ................
        // 2. Si no lo he encontrado
        if (false){
            NoExisteAlumnoException e = new NoExisteAlumnoException(dni,curso+"-"+siglas);
            excepciones.add(e);
            throw e;
        }else return null;
        
        
    }
    
}
