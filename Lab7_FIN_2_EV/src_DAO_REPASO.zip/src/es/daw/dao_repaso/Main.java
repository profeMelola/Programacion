package es.daw.dao_repaso;

import es.daw.dao_repaso.dao.AlumnoDAO;
import es.daw.dao_repaso.model.Alumno;
import es.daw.dao_repaso.model.Aula;
import es.daw.dao_repaso.model.NoExisteAlumnoException;
import java.util.ArrayList;

/**
 *
 * @author melola
 */
public class Main {

    static ArrayList<Alumno> listaAlumnos;
    static ArrayList<Alumno> listaAlumnos2;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //1. Obtener listado de alumnos
        AlumnoDAO dao = new AlumnoDAO();
        listaAlumnos = dao.select();
        listaAlumnos2 = dao.selectClone();

        //pruebasListasAlumnos(dao);
        
        buscarXDNI();
        
    }
    
    public static void pruebasListasAlumnos(AlumnoDAO dao){
        /****************************************************/
        /************ DIFERENTES PRUEBAS *******************/
        System.out.println("* Lista de alumnos por orden de alta en el arraylist:");
        System.out.println(listaAlumnos);
        
        //2. Voy a obtener el primer alumno del ArrayList (el primero de la clase)
        // y luego voy a modificar su nombre
        System.out.println("* PROBANDO A MODIFICAR OBJETOS!!!!");
        System.out.println("* CASO 1: CLONADO SOLO ARRAYLIST");
        Alumno a = listaAlumnos.get(0);
        System.out.println("\tPrimer alumno:");
        System.out.println(a);
        a.setNombre("JUANITA");
        
        System.out.println("* CASO 2: CLONADO ARRAYLIST + OBJETOS");
        Alumno a2 = listaAlumnos2.get(0);
        System.out.println("\tPrimer alumno:");
        System.out.println(a2);
        a2.setNombre("MENGANITA"); //en este caso, no se modifica el nombre del objeto
                                    // del DAO
        
        
        ArrayList<Alumno> l = dao.select(); //vuelvo a cargar la lista de alumnos
        System.out.println("* Lista de alumnos:");
        System.out.println(l);
        System.out.println("Número de alumnos: "+l.size());
        
        // Voy a borrar el primer alumno 
        l.remove(0);
        System.out.println("* Lista de alumnos tras borrar:");
        System.out.println(l);
        System.out.println("Número de alumnos: "+l.size());
        
        ArrayList<Alumno> l2 = dao.select();
        System.out.println("* Lista después de cargar de nuevo los alumnos:");
        System.out.println(l2);
        System.out.println("Número de alumnos: "+l2.size());
        /****************************************************************/
        
    }
    /**
     * Método para buscar a un alumno de la clase por DNI.
     * En el caso de que no exista el DNI y por tanto no se encuentre el alumno, se deberá
     * guardar en un ArrayList una excepcion nueva "NoExisteAlumnoException" con el DNI y el nombre
     * de la clase donde no se ha encontrado el alumno
     */
    private static void buscarXDNI(){
        
        //Crear el aula
        Aula aula = new Aula("primero", "DAWB", "Desarrollo deAplicaciones Web","IFP Alonso de Avellaneda");
        aula.setListaAlumnos(listaAlumnos); //he metido cualquiera de las listas con las que he estado probando antes
        
        //Añado un nuevo alumno
        Alumno newAlumno2 = new Alumno("Nuevo", "JJJJJ", "SSS", "00000000A", 1);
        aula.addAlumno(newAlumno2);
        
        //Muestro los alumnos del aula
        for (Alumno a: aula.getListaAlumnos())
            System.out.println(a);

        //Buscar alumno por DNI. En el caso de que no exista el alumno por DNI
        //voy a necesitar capturar la excepción
        try{
            Alumno a = aula.buscarXDNI("00000000A");
            System.out.println(a);
        }catch(NoExisteAlumnoException e){
            e.getMessage();
        }
        
    }
            
    
    
}
