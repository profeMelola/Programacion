package es.daw.dao_repaso.dao;

import es.daw.dao_repaso.model.Alumno;
import java.util.ArrayList;

/**
 *
 * @author melola
 */
public class AlumnoDAO{

    //---------------------------------------------------------------
    //Se mantiene como variable global, simulando una base de datos
    private ArrayList<Alumno> listaAlumnos = new ArrayList<>();
    // --------------------------------------------------------------
    
    public AlumnoDAO(){
        //Cargo los datos como si fuera una base de datos donde se ha volcado la información
        listaAlumnos.add(new Alumno("Natalia", "Grandes", "Antonio", "9999987Y", 28));
        listaAlumnos.add(new Alumno("MariLuz", "Elola", "Rubio", "88888888A", 46));
        listaAlumnos.add(new Alumno("Otro", "Antón", "Berlín", "99995687Y", 18));
        listaAlumnos.add(new Alumno("As", "Barcelona", "Cáceres", "19995687Y", 5));
    }

    /**
     * 
     * @return 
     */
    public ArrayList<Alumno> select() {
        return (ArrayList<Alumno>)listaAlumnos.clone();
    }
    
    /**
     * 
     * @return 
     */
    public ArrayList<Alumno> selectClone() {
        
        ArrayList<Alumno> l2 = new ArrayList<>();
        for(Alumno a:listaAlumnos){
           Alumno a2 = new Alumno(a.getNombre(),a.getApellido1(),a.getApellido2(),a.getDNI(), a.getEdad());
            l2.add(a2);
        }
        
        return l2;
    }

    
}
