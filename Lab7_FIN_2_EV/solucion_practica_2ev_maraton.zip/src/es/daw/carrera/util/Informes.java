package es.daw.carrera.util;

import es.daw.carrera.model.Carrera;
import es.daw.carrera.model.Ciclista;
import es.daw.carrera.model.Corredor;
import es.daw.carrera.model.Participante;
import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author melola
 */
public class Informes {
    
    // PENDIENTE!!!
    
    // CLASE CON LOS MÉTODOS ESTÁTICOS QUE GENERARN LOS INFORMES
    // Y ASÍ LOS QUITAMOS DEL MAIN
    
}
