package es.daw;

import es.daw.dao.EmpleadoDAO;
import es.daw.rrhh.*;

public class Examen2ev {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        departamentoRRHH();

        
    }
    
    
    /**
     * departamentoRRHH
     */
    private static void departamentoRRHH(){
        System.out.println("\n************ DEPARTAMENTO DE RR.HH ***************");
        
        // Pendiente completar
        
    }
    
}
