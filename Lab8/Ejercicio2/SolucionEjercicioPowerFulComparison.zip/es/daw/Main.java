package es.daw;

import es.daw.dao.HumanDAO;
import es.daw.model.Human;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author melola
 */
public class Main {
    public static void main(String[] args) {
        
        // Creo mi ArrayList
        ArrayList<Human> humans = new ArrayList<>();
        
        // Lo inicializo con valores del DAO
        HumanDAO dao= new HumanDAO();
        humans = dao.select();

        // ESTAS ORDENACIONES SE PUEDEN USAR SI LA CLASE HUMAN TIENE IMPLEMENTADO COMPARABLE
        System.out.println("1. Natural order");
        humans.sort(Comparator.naturalOrder());
        humans.forEach(System.out::println);
        
        System.out.println("2. Reverse order");
        humans.sort(Comparator.reverseOrder());
        humans.forEach(System.out::println);
        
        // ORDENACIÓN BÁSICA SIN LAMBDAS. Con una función anónima
        Collections.sort(humans, new Comparator<Human>() {
        @Override
            public int compare(Human h1, Human h2) {
                return h1.getName().compareTo(h2.getName());
            }
        }); 
        System.out.println("3. Ordenación básica por nombre");
        //humans.forEach(System.out::println);
        humans.forEach(h -> System.out.println(h));
        humans.forEach( (h) -> {
            h.setAge(h.getAge()+1);
            System.out.println(h.getAge());
        });
        
        //Collections.reverseOrder(); //Devuelve un Comparator...
        
        // ORDENACIÓN BÁSICA CON LAMBDAS
        System.out.println("4. Ordenación con lambdas por nombre (especificando tipos)");
        humans.sort( (Human h1, Human h2) -> h1.getName().compareTo(h2.getName()));
        humans.forEach(System.out::println);
        
        // ORDENACIÓN BÁSICA CON LAMBDAS SIN ESPECIFICAR TIPO. INFERENCIA DE TIPOS
        System.out.println("5. Ordenación con lambdas por nombre (sin especificar tipos. Inferencia de tipos)");
        humans.sort((h1, h2) -> h1.getName().compareTo(h2.getName()));
        humans.forEach(System.out::println);
        
        // ORDENACIÓN USANDO UN MÉTODO ESTÁTICO
        System.out.println("6. Ordenación con método estático por nombre y luego edad");
        humans.sort(Human::compareByNameThenAge);
        humans.forEach(System.out::println);
        
        // ORDENACIÓN POR EDAD
        System.out.println("7. Ordenación por nombre descendente con Comparator y lambdas");
        Comparator<Human> nameComparator = (h1, h2) -> h1.getName().compareTo(h2.getName());
        humans.sort(nameComparator.reversed());
        humans.forEach(System.out::println);
        
        // COMPARANDO CON CONDICIONES MÚLTIPLES
        System.out.println("8. Ordenación con condiciones múltiples (nombre y edad)");
        humans.sort(Comparator.comparing(Human::getName).thenComparing(Human::getAge));
        humans.forEach(System.out::println);
        
        
        // COMPARANDO CON JAVA 8 STREAM (EN VEZ DE COMPARATORS)
        /*
        // Los Streams en java son un nuevo modelo de datos que nos permite tratar 
        // las colecciones como si de etapas de un proceso ETL (“Extract Transform and Load”) se tratara. 
        // https://www.arquitecturajava.com/java-stream/
        // https://www.arquitecturajava.com/java-stream-sorted-y-comparators/
        List<String> letters = Arrays.asList("B","A","C","D");
        List<String> sortedLetters = letters.stream().sorted().collect(Collectors.toList());
        sortedLetters.forEach(System.out::println);*/
    
        System.out.println("9. Ordenación por nombre usando stream");
        ArrayList<Human> sortedHumans = (ArrayList<Human>) humans.stream().sorted(nameComparator).collect(Collectors.toList());        
        sortedHumans.forEach(System.out::println);
        
        
    }
}
