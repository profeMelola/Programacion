package es.daw.dao;

import es.daw.model.Human;
import java.util.ArrayList;

/**
 *
 * @author melol
 */
public class HumanDAO {

    ArrayList<Human> humans;
    
    public HumanDAO() {
        humans = new ArrayList<>();
        humans.add(new Human("Ana",10));
        humans.add(new Human("Luis",15));
        humans.add(new Human("Pepe",5));
        humans.add(new Human("Juan",20));
        humans.add(new Human("Ana",17));
    }

    public ArrayList<Human> select(){
        return (ArrayList<Human>)humans.clone();
    }
    
}
