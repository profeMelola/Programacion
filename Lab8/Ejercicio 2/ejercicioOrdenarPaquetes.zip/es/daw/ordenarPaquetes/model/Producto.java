package es.daw.ordenarPaquetes.model;

import java.util.Random;
//Clase a partir de la cual se crearan los diferentes productos con unos valores aleatorios.
public class Producto {
	//Variables que guardan las caracteristicas de los objetos.
	private int alto;	
	private int ancho;
	private int largo;
	private int id;
	//Variable contador que asigna un id diferente a los productos según se van creando
	private static int numId=1;

    public Producto(int alto, int ancho, int largo) {
        this.alto = alto;
        this.ancho = ancho;
        this.largo = largo;
        this.id= numId;
        this.numId++;
        
    }
	
	public Producto() {
		
		id=numId;
		/*Cada vez que se crea un producto el contador se incrementa en uno, 
		de este modo se le asignará un id diferente a cada producto.*/
		numId++;
		
	}
	//Métodos getter y setter que permiten el acceso a las variables.
	public int getAlto() {
		return alto;
	}

	public void setAlto(int alto) {
		this.alto = alto;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getLargo() {
		return largo;
	}

	public void setLargo(int largo) {
		this.largo = largo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	//Sobreescritura del método toString que devuelve las caracteristicas del producto.
	@Override
	public String toString() {
		return "Id: "+id+"  - Alto: "+alto+" - Ancho: "+ancho+" -  Largo: "+largo;
	}
}
