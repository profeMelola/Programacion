package es.daw.ordenarPaquetes;

import es.daw.ordenarPaquetes.model.Producto;
import es.daw.ordenarPaquetes.dao.DAOProductos;
import java.util.Arrays;

public class Principal {

    public static void main(String[] args) {

        Producto[] productosPrueba;
		
        // Cargamos productos del DAO

        // mostrar los productos sin ordenar
        System.out.println("Estos son los productos: ");
        
		
        //Se ordenan los productos por su altura 
        System.out.println("Estos son los productos  ordenados por altura:");
		
        //Se ordenan los productos por su anchura
        System.out.println("Estos son los productos  ordenados por anchura:");
		
        //Se ordenan los productos por su longitud 
        System.out.println("Estos son los productos  ordenados por longitud:");
    }


    /**
     * imprimeArray
     *
     * @param a
     */
    public static void imprimeArray(Producto[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i].toString());
        }
    }
}
