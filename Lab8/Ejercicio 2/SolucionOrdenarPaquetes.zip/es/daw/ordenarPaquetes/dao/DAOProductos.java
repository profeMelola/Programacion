package es.daw.ordenarPaquetes.dao;


import es.daw.ordenarPaquetes.model.Producto;
import java.util.Arrays;


/**
 *
 * @author melola
 */
public class DAOProductos {

    /**
     * Alto: desde 2 cm hasta 30 cm Ancho: desde 2 cm hasta 10 cm Largo: desde 2
     * cm hasta 10 cm
     */
    
    static final int tamanio = 10;
    private Producto[] catalogo;
    
    public DAOProductos(){
        catalogo = new Producto[tamanio];
        catalogo[0] = new Producto(2, 2, 10);
        catalogo[1] = new Producto(29, 10, 2);
        catalogo[2] = new Producto(2, 3, 9);
        catalogo[3] = new Producto(28, 9, 3);
        catalogo[4] = new Producto(3, 4, 8);
        catalogo[5] = new Producto(27, 8, 4);
        catalogo[6] = new Producto(4, 5, 7);
        catalogo[7] = new Producto(26, 7, 5);
        catalogo[8] = new Producto(5, 6, 6);
        catalogo[9] = new Producto(25, 8, 4);    
    }

    public Producto[] select() {
        return catalogo.clone();

    }

}
