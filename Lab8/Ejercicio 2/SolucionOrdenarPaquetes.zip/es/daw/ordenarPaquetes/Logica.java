package es.daw.ordenarPaquetes;

import es.daw.ordenarPaquetes.model.Producto;

public class Logica {
    
    /**
     * Método burbuja mejorado que nos permite ordenar el array de productos en función de la altura de cada uno.
     * @param coleccion
     * @return 
     */
    public static Producto[] ordenarAlto(Producto[] coleccion) {

        Producto[] a = coleccion.clone();

        int n = a.length;
        int j, i;
        Producto aux;

        for (i = 0; i <= n - 2; i++) {
            for (j = 0; j < n - i - 1; j++) {
                if (a[j].getAlto() > a[j + 1].getAlto()) {
                    aux = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = aux;

                }
            }
        }

        return a;
    }
    /**
     * Método de selección que nos permite ordenar el array de productos en función de el ancho de cada uno.
     * @param coleccion
     * @return 
     */
    public static Producto[] ordenarAncho(Producto[] coleccion) {

        Producto[] a = coleccion.clone();
        int posMenor;
        Producto aux;

        for (int e = 0; e < a.length - 1; e++) {

            posMenor = e;
            for (int i = e + 1; i < a.length; i++) {

                if (a[i].getAncho() < a[posMenor].getAncho()) {
                    posMenor = i;

                }

            }
            aux = a[e];
            a[e] = a[posMenor];
            a[posMenor] = aux;

        }
        return a;
    }

    /**
     * Método de inserción que nos permite ordenar el array de productos en función de el largo de cada uno.
     * @param coleccion
     * @return 
     */
    public static Producto[] ordenarLargo(Producto[] coleccion) {

        Producto[] a = coleccion.clone();
        int e, j, k;
        Producto temp;

        for (e = 1; e < a.length; e++) {

            temp = a[e];
            j = 0;
            while (j < a.length && a[j].getLargo() <= temp.getLargo()) {
                j++;
            }

            if (j < e) {

                for (k = e; k > j; k--) {

                    a[k] = a[k - 1];
                }

                a[j] = temp;
            }

        }
        return a;
    }
}
