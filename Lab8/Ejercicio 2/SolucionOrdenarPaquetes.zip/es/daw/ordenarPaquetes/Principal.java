package es.daw.ordenarPaquetes;

import es.daw.ordenarPaquetes.model.Producto;
import es.daw.ordenarPaquetes.dao.DAOProductos;
import java.util.Arrays;
import java.util.Random;

public class Principal {

    public static void main(String[] args) {

        //int numeroPrueba=10;
        Producto[] productosPrueba;
        //productosPrueba = new Producto[numeroPrueba];

        // creamos el array de productos de prueba                    
        //productosPrueba= crearProductos(productosPrueba);
        // cargamos productos del DAO
        DAOProductos dao = new DAOProductos();
        productosPrueba = dao.select();

        // mostrar los productos sin ordenar
        System.out.println("Estos son los productos: ");
        imprimeArray(productosPrueba);
        //Se ordenan los productos por su altura 

        System.out.println("Estos son los productos  ordenados por altura:");
        imprimeArray(Logica.ordenarAlto(productosPrueba));
        //Se ordenan los productos por su anchura

        System.out.println("Estos son los productos  ordenados por anchura:");
        imprimeArray(Logica.ordenarAncho(productosPrueba));
        //Se ordenan los productos por su longitud 

        System.out.println("Estos son los productos  ordenados por longitud:");
        imprimeArray(Logica.ordenarLargo(productosPrueba));
        
        // ---------
        solucionConComparator(productosPrueba);
    }

    /**
     * solucionConComparator
     * @param productosPrueba 
     */
    private static void solucionConComparator(Producto[] productosPrueba){
        Producto[] productos = productosPrueba;
        
        Arrays.sort(productos, (pa,pb) -> Integer.valueOf(pa.getAlto()).compareTo(Integer.valueOf(pb.getAlto())));
        System.out.println("[solucionConComparator] Estos son los productos  ordenados por altura:");
        imprimeArray(productos);
        
        Arrays.sort(productos, (pa,pb) -> Integer.valueOf(pa.getAncho()).compareTo(Integer.valueOf(pb.getAncho())));
        System.out.println("[solucionConComparator] Estos son los productos  ordenados por anchura:");
        imprimeArray(productos);
        
        Arrays.sort(productos, (pa,pb) -> Integer.valueOf(pa.getLargo()).compareTo(Integer.valueOf(pb.getLargo())));
        System.out.println("[solucionConComparator] Estos son los productos  ordenados por longitud:");
        imprimeArray(productos);
        
        
    }
    /**
     * Para el caso de generar aleatoriamente los paquetes en vez de usar el DAO
     *
     * @param productosPrueba
     * @return
     */
    private static Producto[] crearProductos(Producto[] productosPrueba) {
        int alto, ancho, largo;
        for (int i = 0; i < productosPrueba.length; i++) {
            Random r1 = new Random(999 + i);
            //L valor entero entre 2 y 30.
            alto = r1.nextInt(28) + 2;
            // valor entero entre 2 y 10.
            ancho = r1.nextInt(8) + 2;
            // valor entero entre 2 y 10.
            largo = r1.nextInt(8) + 2;
            //    public Producto(int alto, int ancho, int largo) {

            productosPrueba[i] = new Producto(alto, ancho, largo);
        }

        return productosPrueba;

    }

    /**
     * imprimeArray
     *
     * @param a
     */
    public static void imprimeArray(Producto[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i].toString());
        }
    }
}
