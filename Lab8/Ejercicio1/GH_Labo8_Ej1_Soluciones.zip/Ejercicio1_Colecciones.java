//package ejercicio1_colecciones;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author circe
 */
public class Ejercicio1_Colecciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int num = 0;
        ArrayList<Integer> numeros = new ArrayList<>();
        ArrayList<Integer> numerosPares = new ArrayList<>();
        ArrayList<Integer> numerosSinMulti3 = new ArrayList<>();
        
        do{
            System.out.println("Introduce un número entero: ");
            num = sc.nextInt();
            
            numeros.add(num);
            
        } while (num != -1);
        
        // Mostrar lista completa
        System.out.println("*** La lista completa de números es: " + numeros + " ***");
        
        // Mostrar los valores pares
        for (Integer n: numeros) {
            if(n % 2 == 0) {
                numerosPares.add(n);
            }
        } 
        
        System.out.println("*** La lista de números pares es: " + numerosPares + " ***");
        
        // Eliminar los multiplos de 3
        for (Integer n: numeros) {
            if(n % 3 != 0) {
                numerosSinMulti3.add(n);
            }
        } 
        
        System.out.println("*** La lista de números sin múltiplos de 3: " + numerosSinMulti3 + " ***");
    }
    
}
