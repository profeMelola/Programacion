
package es.daw.rrhh;

/**
 *
 * @author melola
 */
public class FormatoDNIException extends Exception{
    private String DNI;

    public FormatoDNIException(String DNI) {
        this.DNI = DNI;
    }

    @Override
    public String getMessage() {
        return "El DNI "+DNI+" tiene un formato incorrecto. Debe empezar por 8 dígitos y acabar con una letra en mayúsculas";
    }
    
    
}
