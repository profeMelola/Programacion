
package es.daw.rrhh;

/**
 *
 * @author melola
 */
public class EmpleadoFijo extends Empleado{
    private double importePlanPensiones;

    public EmpleadoFijo(double importePlanPensiones, String nombre, String apellido1, String apellido2, String DNI, String categoria) {
        super(nombre, apellido1, apellido2, DNI, categoria);
        this.importePlanPensiones = importePlanPensiones;
    }

    public double getImportePlanPensiones() {
        return importePlanPensiones;
    }

    public void setImportePlanPensiones(double importePlanPensiones) {
        this.importePlanPensiones = importePlanPensiones;
    }

    @Override
    public String toString() {
        StringBuilder sb=new StringBuilder();
        sb.append(super.toString());
        return sb+"EmpleadoFijo{" + "ImportePlanPensiones=" + importePlanPensiones + '}';        
    }

    /**
     * 
     * @return 
     */
    public int calcularFactorPagaExtra(){
        int factor = 0;
        switch(getCategoria()){
            case "DIRECTIVO":
                factor = 3;
                break;
            case "SENIOR":
                factor = 2;
                break;
            case "JUNIOR":
                factor = 1;
                break;
            
        }
        return factor;
    }
    
    
}
