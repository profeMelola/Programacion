package es.daw.rrhh;

import es.daw.util.Utilidades;

/**
 *
 * @author melola
 */
public class EmpleadoTemporal extends Empleado{
    private String fechaFinContrato;

    public EmpleadoTemporal(String fechaFinContrato, String nombre, String apellido1, String apellido2, String DNI, String categoria) {
        super(nombre, apellido1, apellido2, DNI, categoria);
        this.fechaFinContrato = fechaFinContrato;
    }

    public String getFechaFinContrato() {
        return fechaFinContrato;
    }
    
    
    
    @Override
    public String toString() {
        StringBuilder sb=new StringBuilder();
        sb.append(super.toString());
        return sb+"EmpleadoTemporal{" + "FechaFinContrato=" + fechaFinContrato + '}';
    }    
    
    public int calcularFactorPagaExtra(){
        return Utilidades.calculaDiasEntreFechas(getFechaInicioContrato(),getFechaFinContrato());
    }
}
