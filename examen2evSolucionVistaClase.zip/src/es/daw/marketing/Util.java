package es.daw.marketing;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {

    public static String reemplazarPalabra(String texto, String palabraOriginal, String palabraReemplazar) {
        return texto.replaceAll(palabraOriginal, palabraReemplazar);
    }

    public static String reemplazarPalabraST(String texto, String palabraOriginal, String palabraReemplazar) {
        ArrayList<String> frase = new ArrayList<>();
        StringTokenizer st = new StringTokenizer(texto, " ");
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            if (token.equalsIgnoreCase(palabraOriginal)) {
                frase.add(palabraReemplazar);
            } else {
                frase.add(token);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (String s : frase) {
            sb.append(s + " ");
        }
        return sb.toString();
    }
    
    public static String reemplazarPalabraSplit(String texto, String palabraOriginal, String palabraReemplazar) {
       String[] array=texto.split(" ");
        for (int i = 0; i < array.length; i++) {
            if(array[i].equals(palabraOriginal)){
                array[i]=palabraReemplazar;
            }
        }
        String texto2="";
        for (int i = 0; i < array.length; i++) {
            texto2+=array[i]+" ";
        }

       return texto2;
    }    
      
    public static String reemplazarPalabraSB(String text, String patternString, String sustituir) {
       
        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(text);
        
        StringBuilder sb = new StringBuilder(text);

        int count = 0;
        while (matcher.find()) {
            count++;
            //System.out.println("found: " + count + " : "+ matcher.start() + " - " + matcher.end());
            sb.replace(matcher.start(), matcher.end(), sustituir);
        }
       
       return sb.toString();
       //return text.replaceAll(patternString, sustituir);
       
    }    

}
