package es.daw.dao;

import es.daw.rrhh.*;
import java.util.ArrayList;

public class EmpleadoDAO {
    private ArrayList<Empleado> empleados = new ArrayList<>();
    
    public EmpleadoDAO(){
        
        empleados.add(new EmpleadoFijo(1000, "B", "B", "B", "11111111C", "DIRECTIVO"));
        empleados.add(new EmpleadoFijo(2000, "B", "B", "C", "11111111B", "SENIOR"));
        empleados.add(new EmpleadoFijo(3000, "A", "B", "C", "11111111A", "JUNIOR"));
        empleados.add(new EmpleadoTemporal("2022-04-01", "C", "B", "B", "11111111Y", "DIRECTIVO"));
        empleados.add(new EmpleadoTemporal("2022-04-01", "D", "B", "C", "22222222B", "SENIOR"));
        empleados.add(new EmpleadoTemporal("2022-05-19", "C", "B", "C", "22222222A", "JUNIOR"));
    }
    
    public ArrayList<Empleado> select() {
        return (ArrayList<Empleado>) empleados.clone();
    }               
}
