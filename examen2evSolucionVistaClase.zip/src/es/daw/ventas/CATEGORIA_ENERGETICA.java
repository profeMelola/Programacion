/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package es.daw.ventas;

/**
 *
 * @author melola
 */
public enum CATEGORIA_ENERGETICA {
    A(100), B(80), C(60), D(50), E(30), F(10);

    private double plus;

    private CATEGORIA_ENERGETICA(double plus) {
        this.plus = plus;
    }

    public double getPlus() {
        return plus;
    }    
}
