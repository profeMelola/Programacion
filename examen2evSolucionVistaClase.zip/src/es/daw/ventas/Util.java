package es.daw.ventas;

public class Util {
    /*
    public static double getPrecioFinal(String categoria, double precio){
        double precioF = 0;
        switch(categoria){
            case "A":
                precioF += 100;
                break;
                ........
                        
                
        }
    }*/
    
    public static double getPrecioFinal (CATEGORIA_ENERGETICA ce, double precio){
       
        return precio+ce.getPlus();
    }
    /*
    public enum CATEGORIA_ENERGETICA {
        A, B, C, D, E, F
    }
    
    public static double getPrecioFinal(CATEGORIA_ENERGETICA ce, double precio) {

        if (null != ce) switch (ce) {
            case A:
                precio += 100;
                break;
            case B:
                precio += 80;
                break;
            case C:
                precio += 60;
                break;
            case D:
                precio += 50;
                break;
            case E:
                precio += 30;
                break;
            case F:
                precio += 10;
                break;
            default:
                break;
        }

        return precio;
    }   */ 
    
}
