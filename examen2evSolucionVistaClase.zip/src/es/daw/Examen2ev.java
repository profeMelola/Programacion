package es.daw;

import es.daw.dao.EmpleadoDAO;
import es.daw.ventas.*;
import es.daw.rrhh.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class Examen2ev {

    /**
     * @param args the command line arguments
     */
    //public static void main(String[] args) throws FormatoDNIException{
    public static void main(String[] args){
        
        // ------------------------------------------------
        // DEPARTAMENTO DE VENTAS (1,5 puntos)
        // ------------------------------------------------
        departamentoVentas();
        // ------------------------------------------------
        // DEPARTAMENTO DE MARKETING (1 punto)
        departamentoMarketing();        
        // ------------------------------------------------
        // DEPARTAMENTO DE RR.HH (7,5 puntos)
        departamentoRRHH();

        
    }
    
    /**
     * departamentoVentas
     */
    private static void departamentoVentas(){
        System.out.println("\n************ DEPARTAMENTO DE VENTAS ***************");
        Double precio = 1520.8;
        
        System.out.println("Precio final categoría C: "+es.daw.ventas.Util.getPrecioFinal(CATEGORIA_ENERGETICA.A, 1520.8));
        System.out.println("Precio final categoría A: "+es.daw.ventas.Util.getPrecioFinal(CATEGORIA_ENERGETICA.B, 1520.8));
        System.out.println("Precio final categoría B: "+es.daw.ventas.Util.getPrecioFinal(CATEGORIA_ENERGETICA.C, 1520.8));
        System.out.println("Precio final categoría D: "+es.daw.ventas.Util.getPrecioFinal(CATEGORIA_ENERGETICA.D, 1520.8));
        System.out.println("Precio final categoría E: "+es.daw.ventas.Util.getPrecioFinal(CATEGORIA_ENERGETICA.E, 1520.8));
        System.out.println("Precio final categoría F: "+es.daw.ventas.Util.getPrecioFinal(CATEGORIA_ENERGETICA.F, 1520.8));        
        
        
    }
    
    /**
     * departamentoRRHH
     */
    private static void departamentoRRHH(){
    //private static void departamentoRRHH() throws FormatoDNIException{
        System.out.println("\n************ DEPARTAMENTO DE RR.HH ***************");
        
        //Creo la lista de empleados
        ArrayList<Empleado> empleados = new ArrayList<>();
        EmpleadoDAO eDAO = new EmpleadoDAO();
        empleados = eDAO.select();
        /*for (Empleado e: eDAO.select())
            empleados.add(e);        */
        
        System.out.println("\n* Número de empleados creados:");
        System.out.println(Empleado.contador);
        
        
        System.out.println("* Lista de empleados originales:");
        for(Empleado e: empleados)
            System.out.println(e);
        
        // PROBAR AÑADIR UN NUEVO EMPLEADO CON DNI INCORRECTO
        System.out.println("\n* Probrando a crear empleados:");
        try{
            Empleado.checkDNI("11111111Z");
            Empleado nuevoE = new EmpleadoFijo(3000,"Mari", "A", "B", "8888j", "DIRECTIVO");
            empleados.add(nuevoE);
            
        }catch(FormatoDNIException e){
            System.out.println(e.getMessage());
        }
        
        System.out.println("\n* Mostrar empleados ordenación natural desc:");
        
        empleados.sort(Comparator.reverseOrder());
        //Collections.reverse(empleados);
        
        for(Empleado e: empleados)
            System.out.println(e);
        
        
        System.out.println("\n* Mostrar lista de empleados apell1+apell2+nombre:");
        
        empleados.sort( (pa,pb) -> pa.getApellido1().concat(pa.getApellido2().concat(pa.getNombre())).compareTo(pb.getApellido1().concat(pb.getApellido2().concat(pb.getNombre()))));
        empleados.forEach(System.out::println);        
        
        System.out.println("\n* Borrar empleados temporales con fecha fin contrato 2022-04-01:");
        /*for(Empleado e: empleados){
            if (e instanceof EmpleadoTemporal ){
                String ffc = ((EmpleadoTemporal) e).getFechaFinContrato();
                if (ffc.equals("2022-04-01")) empleados.remove(e);
            }
                
        }*/
        
        Iterator it = empleados.iterator();
        while(it.hasNext()){
            Empleado e = (Empleado)it.next();
            if (e instanceof EmpleadoTemporal ){
                String ffc = ((EmpleadoTemporal) e).getFechaFinContrato();
                if (ffc.equals("2022-04-01")){
                    //empleados.remove(e); //KK
                    it.remove();
                }
            }
        }
        System.out.println("\n* Lista de empleados actualizada:");
        empleados.forEach(System.out::println);    
        
        
        System.out.println("\n* Lista de empleados originales:");
        eDAO.select().forEach(System.out::println);
        
        System.out.println("\n* Número de empleados creados:");
        System.out.println(Empleado.contador);
        

        
    }
    
    /**
     * departamentoMarketing
     */
    private static void departamentoMarketing(){
        System.out.println("\n************ DEPARTAMENTO DE MARKETING ***************");
        String eslogan = "OFERTA 2X1 EN PORTÁTILES HASTA EL 15 DE ENERO";
        
        /*eslogan = es.daw.marketing.Util.reemplazarPalabra(eslogan,"PORTÁTILES","CONSOLAS");
        eslogan = es.daw.marketing.Util.reemplazarPalabra(eslogan,"15","20");
        eslogan = es.daw.marketing.Util.reemplazarPalabra(eslogan,"ENERO","FEBRERO");*/
        
        eslogan = es.daw.marketing.Util.reemplazarPalabra(eslogan,"PORTÁTILES HASTA EL 15 DE ENERO","CONSOLAS HASTA EL 20 DE FEBRERO");
        
        System.out.println("NUEVA FRASE PUBLICITARIA: "+eslogan);
        
        
        
    }
            
    
}
