package es.daw.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author melola
 */
public class Utilidades {

    /**
     * Método que calcula el número de días desde una fecha anterior a otra (entre dos fechas).
     * @param dateBeforeString String con la fecha anterior
     * @param dateAfterString String con la fecha posterior
     * @return valor entero con el número de días
     */
    public static int calculaDiasEntreFechas(String fechaAnterior, String fechaPosterior) {

        //Parsing the date
        LocalDate ld_antes = LocalDate.parse(fechaAnterior);
        LocalDate ld_despues = LocalDate.parse(fechaPosterior);

        //calculating number of days in between
        long numDiasEntre = ChronoUnit.DAYS.between(ld_antes, ld_despues);

        //returning the number of days
        return (int)numDiasEntre;
    }
    
    /**
     * Método que devuelve verdadero/falso dependiendo de si se cumple la 
     * expresión regular
     * @param expresionRegular String con la expresión regular
     * @param cadena String con la cadena de texto a validar
     * @return boolean
     */
    public static boolean checkExpresionRegular(String expresionRegular, String cadena){
        Pattern pat = Pattern.compile(expresionRegular);
        Matcher mat = pat.matcher(cadena);
        return (mat.matches());
        
    }
}
