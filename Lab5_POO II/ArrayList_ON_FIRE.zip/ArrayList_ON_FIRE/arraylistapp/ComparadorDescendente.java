package arraylistapp;

import arraylistapp.model.Persona;
import java.util.Comparator;

/**
 *
 * @author melol
 */
//Mientras que Comparable nos obliga a implementar el método compareTo (Object o), 
//la interfaz Comparator nos obliga a implementar el método compare (Object o1, Object o2)
public class ComparadorDescendente implements Comparator<Persona>{
    @Override
    public int compare(Persona p1, Persona p2) {
        Integer edad1 = p2.getEdad();
        Integer edad2 = p1.getEdad();
        return edad1.compareTo(edad2);
    }
    
}