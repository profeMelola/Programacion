package arraylistapp;

import arraylistapp.model.Persona2;
import arraylistapp.model.Persona;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ArrayListApp {

    //private static ArrayList<Integer> arrayListInt = new ArrayList<>();
    //private static ArrayList<Persona> personas = new ArrayList<>();
    public static void main(String args[]) {

        /**
         * ARRAYLIST DE ENTEROS
         */
        // ----------------------------------------------------------
        // EJEMPLO 1: ARRAYLIST DE ENTEROS
        // Guardo datos en el ArrayList
        System.out.println("*****************************************************************************************");
        System.out.println("**************** EJEMPLOS DE ORDENACIÓN DE UN ARRAYLIST DE ENTEROS **********************");
        System.out.println("*****************************************************************************************");
        ArrayList<Integer> arrayListInt = new ArrayList<>();

        arrayListInt.add(3); //autoboxing a tipo Integer
        arrayListInt.add(4);
        arrayListInt.add(2);
        arrayListInt.add(6);
        arrayListInt.add(5);
        arrayListInt.add(1);
        arrayListInt.add(7);

        // Imprimo el arrayList de Enteros desordenado
        System.out.println("ArrayList sin ordenar: ");
        //printArrayListInt();
        printArrayList(arrayListInt);

        // Ordeno el ArrayList de menor a mayor y lo imprimo
        System.out.println("\nArrayList ordenado de menor a mayor");
        Collections.sort(arrayListInt);
        printArrayList(arrayListInt);

        // Ordeno el ArrayList de mayor a menor y lo imprimo
        // La interfaz Comparator nos obliga a implementar el método compare (Object o1, Object o2)
        System.out.println("\nArrayList ordenado de mayor a menor");
        //Comparator<Integer> comparador = Collections.reverseOrder();
        //Collections.sort(arrayListInt, comparador);
        Collections.sort(arrayListInt, Collections.reverseOrder());
        printArrayList(arrayListInt);

        // -------------------------------------------------------------------
        // EJEMPLO 2: ARRAYLIST DE ENTEROS
        List<Integer> slist = Arrays.asList(4, 5, 1, 2, 8, 9, 6);

        System.out.println("* [CON SORT DE COLLECTIONS] ORDENAR ENTEROS EN UN ARRAYLIST:");

        Collections.sort(slist);
        System.out.println("\tOrdenación ascendente: " + slist);
        Collections.sort(slist, Collections.reverseOrder());
        System.out.println("\tOrdenación descendente: " + slist);

        System.out.println("* [CON SORT DE LIST] ORDENAR ENTEROS EN UN ARRAYLIST:");
        slist.sort(Comparator.naturalOrder());
        System.out.println("\tOrdenación ascendente: " + slist);
        slist.sort(Comparator.reverseOrder());
        System.out.println("\tOrdenación descendente: " + slist);

        // *************************************************************************
        /**
         * ARRAYLIST DE OBJETOS PERSONA
         */
        System.out.println("*****************************************************************************************");
        System.out.println("**************** EJEMPLOS DE ORDENACIÓN DE UN ARRAYLIST DE PERSONAS**********************");
        System.out.println("*****************************************************************************************");

        //--------------------------------
        // 1. USANDO INTERFACE COMPARATOR
        //---------------------------------
        ArrayList<Persona> personas = new ArrayList<>();
        // Guardo datos en el ArrayList de Objetos de la clase persona
        /*personas.add(new Persona("Pepe", 28));
        personas.add(new Persona("Juan", 32));
        personas.add(new Persona("Paco", 40));
        personas.add(new Persona("Lola", 20));
        personas.add(new Persona("Jose", 28));
        personas.add(new Persona("Dani", 24));
        personas.add(new Persona("Sara", 36));
        personas.add(new Persona("Susi", 24));*/

        Persona p1 = new Persona("Pepe", 28);
        Persona p2 = new Persona("Juan", 32);
        Persona p3 = new Persona("Paco", 40);
        Persona p4 = new Persona("Lola", 20);
        Persona p5 = new Persona("Jose", 28);
        Persona p6 = new Persona("Dani", 24);
        Persona p7 = new Persona("Sara", 36);
        Persona p8 = new Persona("Susi", 24);

        //List es una interface y ArrayList es una implementación de List
        //Mirar gráfico del aula virtual
        List<Persona> lista = Arrays.asList(p1, p2, p3, p4, p5, p6, p7, p8);
        //personas = new ArrayList<Persona>(lista);
        //personas = (ArrayList)lista; //error!!!

        // Imprimo el ArrayList desordenado por edad de la clase persona
        System.out.println("\nArrayList desordenada");
        //printArrayListPersona();
        //printArrayList(personas);
        lista.forEach(System.out::println);

        // Odeno el arrayList de menor a mayor por edad y lo imprimo
        System.out.println("\nArrayList ordenado por edad de mayor a menor:");
        //Collections.sort(personas, new ComparadorDescendente());
        //printArrayListPersona();
        //printArrayList(personas);
        Collections.sort(lista, new ComparadorDescendente());
        lista.forEach(System.out::println);

        // Odeno el arrayList de mayor a menor por edad y lo imprimo
        //Mientras que Comparable nos obliga a implementar el método compareTo (Object o), 
        //la interfaz Comparator nos obliga a implementar el método compare (Object o1, Object o2)
        System.out.println("\nArrayList ordenado por edad de menor a mayor:");
        /*Collections.sort(personas, new Comparator<Persona>() {
            @Override
            public int compare(Persona p1, Persona p2) {
                // Aqui esta el truco, ahora comparamos p2 con p1 y no al reves como antes
                Integer edad1 = p2.getEdad();
                Integer edad2 = p1.getEdad();
                return edad2.compareTo(edad1);
            }
        });*/
        //printArrayListPersona();
        //printArrayList(personas);
        Collections.sort(lista, new Comparator<Persona>() {
            @Override
            public int compare(Persona p1, Persona p2) {
                // Aqui esta el truco, ahora comparamos p2 con p1 y no al reves como antes
                Integer edad1 = p2.getEdad();
                Integer edad2 = p1.getEdad();
                return edad2.compareTo(edad1);
            }
        });

        // ------------------------------------------------------------------------------
        // A partir de Java 8 con expresiones Lambda
        //Ordenar ascendente
        System.out.println("********************* EXPRESIONES LAMBDA ******************");
        System.out.println("* Ordenación de personas por edad ascendente: ");
        //personas.sort((pa,pb) ->Integer.valueOf(pa.getEdad()).compareTo(Integer.valueOf(pb.getEdad())));
        //personas.forEach(System.out::println);
        lista.sort((pa, pb) -> Integer.valueOf(pa.getEdad()).compareTo(Integer.valueOf(pb.getEdad())));
        lista.forEach(System.out::println);

        System.out.println("* Ordenación de personas por edad descendente: ");
        //personas.sort((pa,pb) ->Integer.valueOf(pb.getEdad()).compareTo(Integer.valueOf(pa.getEdad())));
        //personas.forEach(System.out::println);
        lista.sort((pa, pb) -> Integer.valueOf(pb.getEdad()).compareTo(Integer.valueOf(pa.getEdad())));
        lista.forEach(System.out::println);

        // ----------- AHORA QUIERO ORDENAR POR NOMBRE ------------
        System.out.println("* Ordenación de personas por nombre: ");
        //personas.sort((pa,pb) -> pa.getNombre().compareTo(pb.getNombre()));
        //personas.forEach(System.out::println);
        lista.sort((pa, pb) -> pa.getNombre().compareTo(pb.getNombre()));
        lista.forEach(System.out::println);

        System.out.println("**********************************************************");

        //--------------------------------
        // 2. USANDO INTERFACE COMPARABLE
        //---------------------------------        for(Persona p: personas)

        System.out.println("********* Ordenación usando la interfaz comparable ***************");
        ArrayList<Persona2> personas2 = new ArrayList<Persona2>();
        personas2.add(new Persona2("Pepe", 28));
        personas2.add(new Persona2("Juan", 32));
        personas2.add(new Persona2("Paco", 40));
        personas2.add(new Persona2("Lola", 20));
        personas2.add(new Persona2("Jose", 28));
        personas2.add(new Persona2("Dani", 24));
        personas2.add(new Persona2("Sara", 36));
        personas2.add(new Persona2("Susi", 24));

        System.out.println("\tArrayList de personas2 sin ordenar: ");
        printArrayList(personas2);

        System.out.println("\tArrayList de personas2 ordenado ascendente: ");
        Collections.sort(personas2);
        printArrayList(personas2);

        System.out.println("\tArrayList de personas2 ordenado descendente: ");
        personas2.sort(Comparator.reverseOrder());
        printArrayList(personas2);

        // ------------------ Añado nuevo criterio de ordenación ------------
        // PRIMERA FORMA:Quiero ordenar por nombre
        System.out.println("\tArrayList de personas2 ordenado by name:");
        Collections.sort(personas2, new ComparatorByNameP2());
        personas2.forEach(System.out::println);

        // SEGUNDA FORMA
        System.out.println("\tArrayList de personas2 ordenado by edad:");
        Collections.sort(personas2, new Comparator<Persona2>() {
            @Override
            public int compare(Persona2 p1, Persona2 p2) {
                // Aqui esta el truco, ahora comparamos p2 con p1 y no al reves como antes
                Integer edad1 = p2.getEdad();
                Integer edad2 = p1.getEdad();
                return edad2.compareTo(edad1);
            }
        });
        personas2.forEach(System.out::println);
        
        // -------------------------------
        // TERCERA FORMA
        System.out.println("\tArrayList de personas2 ordenado by nombre II:");
        Collections.sort(personas2, new Comparator<Persona2>() {
            @Override
            public int compare(Persona2 p1, Persona2 p2) {  
                return p1.getNombre().compareTo(p2.getNombre());
            }
        });
        personas2.forEach(System.out::println);
        //-------------------------------------------------
        
        // -------------------------------
        // CUARTA FORMA CON LAMBDAS
        System.out.println("\tArrayList de personas2 ordenado con lambdas:");
        personas2.sort((persona1,persona2) -> persona1.getNombre().compareTo(persona2.getNombre()));
        // ---------------------------
            
        
        
        
        
        // ---------------------- PRUEBAS DE OPERACIONES BÁSICAS SOBRE UN ARRAYLIST -------------
        // 1. BORRAR UN OBJETO CONCRETO A PARTIR DEL NOMBRE
        // Consideramos que las personas se diferencias por el nombre
        borrarElementoListaByName(personas2, "Lola");
        System.out.println("\tLista de personas después de borrar a Lola:");
        printArrayList(personas2);

        // 2. BORRAR UN OBJETO CONCRETO A PARTIR DE UN OBJETO
        Persona2 juan = new Persona2();
        juan.setNombre("Juan");
        System.out.println("\tLista de personas después de borrar a Juan:");
        borrarElementoListaByName(personas2, juan);
        printArrayList(personas2);

    }

    /**
     *
     * MÉTODOS AUXILIARES ESTÁTICOS
     */
    private static void printArrayList(ArrayList arraylist) {
        Iterator itrArrayList = arraylist.iterator();
        int posicion = 1;
        while (itrArrayList.hasNext()) {
            System.out.println("Posicion(" + posicion + ") = " + itrArrayList.next());
            posicion++;
        }
    }

    // -----------------------------------------
    /*
    private static void printArrayListInt() {
        Iterator<Integer> itrArrayList = arrayListInt.iterator();
        int posicion = 1;
        while (itrArrayList.hasNext()) {
            System.out.println("Posicion(" + posicion + ") = " + itrArrayList.next());
            posicion++;
        }
    }

    private static void printArrayListPersona() {
        Iterator<Persona> itrArrayList = personas.iterator();
        int posicion = 1;
        while (itrArrayList.hasNext()) {
            System.out.println("Posicion(" + posicion + ") = " + itrArrayList.next().toString());
            posicion++;
        }
    }*/
    // -----------------------------------------
    private static void borrarElementoListaByName(ArrayList<Persona2> personas, String nombre) {
        //1. Encontrar el objeto con dicho nombre
        Persona2 p2 = null;
        for (Persona2 p : personas) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                p2 = p;
                personas.remove(p); //PROBLEMAS POR BORRAR DIRECTAMENTE EN EL EACH!!! ESTÁ EXPLICADO EN EL AULA VIRTUAL
                break;
            }
        }
        System.out.println("p2: " + p2);

        //2. Borro
        if (p2 != null) {
            //int pos = personas.indexOf(p2);
            //if (pos > 0) personas.remove(pos);
            personas.remove(p2);
        }
    }

    private static void borrarElementoListaByName(ArrayList<Persona2> personas, Persona2 p2) {
        /*int pos = personas.indexOf(p2);
        
        if (pos > 0)
            personas.remove(pos);*/

        personas.remove(p2);

    }
}
