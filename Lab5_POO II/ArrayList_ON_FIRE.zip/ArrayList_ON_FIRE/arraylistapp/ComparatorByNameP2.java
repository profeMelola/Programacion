package arraylistapp;

import arraylistapp.model.Persona2;
import java.util.Comparator;

/**
 *
 * @author melola
 */
public class ComparatorByNameP2 implements Comparator<Persona2>{

    @Override
    public int compare(Persona2 p1, Persona2 p2) {  
        return p1.getNombre().compareTo(p2.getNombre());
    }
    
}
