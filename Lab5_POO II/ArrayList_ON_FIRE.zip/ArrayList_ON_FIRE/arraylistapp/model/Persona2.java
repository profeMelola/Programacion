package arraylistapp.model;

//Mientras que Comparable nos obliga a implementar el método compareTo (Object o), 

import java.util.Objects;

//la interfaz Comparator nos obliga a implementar el método compare (Object o1, Object o2)

//¿CUÁNDO USAR UNA U OTRA????????
//Un objeto debería implementar Comparable si esa es la forma natural clara de ordenar la clase, 
//y cualquiera que necesite ordenar la clase generalmente querrá hacerlo de esa manera.
//Implementar comparator nos permite ordenar de varias formas e implementar Comparable solo forma de una.
/*
Utilizar Comparable:

si el objeto está bajo su control.
si el comportamiento de comparación es el principal comportamiento de comparación.
Utilizar Comparator:

si el objeto está fuera de su control y no puede hacer que se implementen Comparable.
cuando desee comparar un comportamiento diferente del comportamiento predeterminado (que está especificado por Comparable).
*/

public class Persona2 implements Comparable<Persona2>{

    private String nombre;
    private int edad;

    public Persona2() {
    }

    public Persona2(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return this.getNombre() + "  -  " + this.getEdad();
    }

    
    @Override
    /**
     * Reglas:
     *  Devuelve 0 en caso de que ambos objetos tengan el mismo orden (no haya uno mayor que otro)
        Un número entero negativo si el objeto actual es menor al objeto pasado como parámetro
        Un número positivo si el objeto actual es mayor al objeto pasado como parámetro
     */
    public int compareTo(Persona2 p){
        if (p.getEdad() > edad)
            return -1;
        else if (p.getEdad() == edad)
            return 0;
        else
            return 1;
        
        //return edad - p.getEdad();
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persona2 other = (Persona2) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }
    
    
}
