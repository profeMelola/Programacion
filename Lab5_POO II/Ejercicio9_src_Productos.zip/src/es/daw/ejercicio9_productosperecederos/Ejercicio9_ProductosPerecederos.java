package es.daw.ejercicio9_productosperecederos;

import es.daw.ejercicio9_productosperecederos.dao.ProductoDAO;
import es.daw.ejercicio9_productosperecederos.model.*;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;

/**
 *
 * @author melol
 */
public class Ejercicio9_ProductosPerecederos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // 1. CARGO LOS DATOS DEL DAO
        ProductoDAO dao = new ProductoDAO();
        ArrayList<Producto> productos = dao.select();

        // 2. MUESTRO MI COLECCIÓN DE PRODUCTOS
        System.out.println("* Lista de productos:");
        listarProductos(productos);

        // 3. BORRAR
        System.out.println("\nNúmero de productos en el almacen:" + productos.size());
        try {
            eliminarProductos(productos);
        } catch (ConcurrentModificationException e) {

            System.err.println("*********** ERROR AL BORRAR ***********");

        } catch (MiExcepcion e){
            System.err.println("*********** ERROR MIEXCEPCION ***********");
            System.err.println(e.getMessage());
        }
        catch (Exception e) {
            System.err.println("************* EXCEPCIÓN GENERAL **********");
            System.err.println(e.getMessage());
        }
        System.out.println("\nNúmero de productos en el almacen después borrar:" + productos.size());

    }

    private static void listarProductos(ArrayList<Producto> productos) {
        for (Producto p : productos) {
            System.out.println(p);
            System.out.println("\tPrecio final de 5 productos:" + p.calcular(5));
            System.out.println("\tPermite devolución:" + p.permiteDevolucion());
            System.out.println("\tPlantilla XML:" + p.getPlantillaXML());
        }

    }

    //private static void eliminarProductos(ArrayList<Producto> productos){
    private static void eliminarProductos(ArrayList<Producto> productos) throws MiExcepcion {
        //private static void eliminarProductos(ArrayList<Producto> productos) throws ConcurrentModificationException{
        // Borrar los elementos perecederos que tiene más de 5 días de caducidad

        // Forma incorrecto. No controlo si puede propagar excepción
        /*for(Producto p:productos){
            if ( p instanceof Perecedero){
                if ( ((Perecedero) p).getDiasCaducar() > 5)
                    productos.remove(p);
            }
        }*/
        Iterator it = productos.iterator();

        while (it.hasNext()) {
            Producto p = (Producto) it.next();
            if (p instanceof Perecedero) {
                if (((Perecedero) p).getDiasCaducar() > 5) {
                    it.remove();
                }
                //Exception e = new Exception("Excepción que me invento");
                MiExcepcion e = new MiExcepcion(p.getNombre());
                throw e;
            }
        }
    }

}
