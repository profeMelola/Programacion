package es.daw.ejercicio9_productosperecederos.model;

/**
 *
 * @author melola
 */
public class Perecedero extends Producto{
    private int diasCaducar;

    public Perecedero(int diasCaducar, String nombre, double precio) {
        super(nombre, precio);
        this.diasCaducar = diasCaducar;
    }

    public int getDiasCaducar() {
        return diasCaducar;
    }

    public void setDiasCaducar(int diasCaducar) {
        this.diasCaducar = diasCaducar;
    }

    @Override
    /**
     * Método que devuelve el precio final en base
     * a la cantidad de productos comprados
     */
    public double calcular(int cantidad){
        double precioT = super.calcular(cantidad);
        
        //Además, el precio se reducirá según los días a caducar
        switch (diasCaducar){
            case 1:
                precioT = precioT - (precioT*25)/100;
                break;
            case 2:
                precioT = precioT - (precioT*33)/100;
                break;
            case 3:
                precioT = precioT - precioT/2;
                break;
                
        }
        return precioT;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Perecedero{" + "diasCaducar=" + diasCaducar + '}');
        return sb.toString();
    }

    @Override
    public boolean permiteDevolucion() {
        if (diasCaducar > 5) return true;
        else return false;
    }

    @Override
    public String getPlantillaXML() {
        return "<producto>producto perecedero</producto>";
    }
    
    

    
}
