package es.daw.ejercicio9_productosperecederos.model;

import java.util.Objects;

/**
 *
 * @author melola
 */
//public abstract class Producto implements ConvertibleToXML, Comparable<Producto>{
public abstract class Producto implements ConvertibleToXML{        
    private String nombre;
    private double precio;

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    // MÉTODO PROPIO
    public double calcular(int cantidad){
        double precioTotal = precio * cantidad;
        return precioTotal;
    }
    
    // MÉTODO ABSTRACTO
    public abstract boolean permiteDevolucion();
    
    @Override
    public String toString() {
        return "Producto{" + "nombre=" + nombre + ", precio=" + precio + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        return Objects.equals(this.nombre, other.nombre);
    }

    /* PENDIENTE IMPLEMENTAR CON EL MÉTODO NATURAL DE ORDENACIÓN */
    /*@Override
    public int compareTo(Producto arg0) {
        // 
    }*/
    
    
}
