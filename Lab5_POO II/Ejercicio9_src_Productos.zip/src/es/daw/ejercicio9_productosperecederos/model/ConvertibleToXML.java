package es.daw.ejercicio9_productosperecederos.model;

/**
 *
 * @author melola
 */
public interface ConvertibleToXML {
    public String getPlantillaXML();
}
