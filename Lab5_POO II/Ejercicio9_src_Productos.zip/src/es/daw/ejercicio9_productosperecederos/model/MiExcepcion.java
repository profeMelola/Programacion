/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.daw.ejercicio9_productosperecederos.model;

/**
 *
 * @author melola
 */
public class MiExcepcion extends Exception{
    private String nombre;

    public MiExcepcion(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getMessage() {
        return "PEDAZO DE ERROR EN EL PRODUCTO "+nombre;
    }
    
    
}
