package es.daw.parkingalcala;

import es.daw.parkingalcala.excepciones.ParkingCompletoException;
import es.daw.parkingalcala.model.Coche;
import es.daw.parkingalcala.model.Parking;
import es.daw.parkingalcala.model.ParkingPrivado;
import es.daw.parkingalcala.model.ParkingPublico;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author melola
 */
public class App {

    // Creo a nivel global colección para guardar Excepciones (me lo pide el enunciado)
    static ArrayList<ParkingCompletoException> excepciones = new ArrayList<>();   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // SET DE PRUEBAS
        // 1. Creo dos parkings de cada tipo
        ParkingPublico ppubl = new ParkingPublico(2, "P PUBLI 1", "Camino de la Esgaravita", 10);
        //ParkingPublico ppubl2 = new ParkingPublico(1, "P PUBLI 2", "Camino de la Esgaravita 2", 5);
        
        ParkingPrivado ppriv = new ParkingPrivado(2, "P PRIVADO 1", "Dir 1", 3);
        //ParkingPrivado ppriv2 = new ParkingPrivado(1, "P PRIVADO 2", "Dir 2", 2);
        
        
        // 2. Creo una lista de coches a meter en el parking
        ArrayList<Coche> listaCoches = new ArrayList<>();
        cargaCoches(listaCoches);
        
        // 3. Cargo coches en los diferentes parkings
        cargaCochesEnParking(ppubl,listaCoches);
        //cargaCochesEnParking(ppubl2,listaCoches.subList(0, listaCoches.size() - 1));
        cargaCochesEnParking(ppriv,listaCoches);
        //cargaCochesEnParking(ppriv2,listaCoches.subList(0, listaCoches.size() - 2));
        
        
        // Mostrar info de los parkings
        System.out.println("****************************");
        System.out.println("* INFO PARKINGS PÚBLICOS: ");
        System.out.println("****************************");
        System.out.println(ppubl.toString());
        System.out.println("Ganancias: "+ppubl.mostrarGananciasTotales());
        System.out.println("");
        
        /*
        System.out.println("AHORA SE VA EL CUARTO COCHE DEL PARKING!!!!");
        ppubl.deleteCoche(3); //es eléctrico, las ganancias segurirán sigiendo las mismas
        System.out.println(ppubl.toString());
        System.out.println("Ganancias: "+ppubl.mostrarGananciasTotales());
        System.out.println("");
        
        System.out.println("AHORA SE VA EL PRIMER COCHE DEL PARKING!!!!");
        ppubl.deleteCoche(0);
        System.out.println(ppubl.toString());
        System.out.println("Ganancias: "+ppubl.mostrarGananciasTotales());
        System.out.println("");*/
        
        //System.out.println(ppubl2.toString());
        //System.out.println("Ganancias: "+ppubl2.mostrarGananciasTotales());
        //System.out.println("");
        System.out.println("****************************");
        System.out.println("* INFO PARKINGS PRIVADOS: ");
        System.out.println("****************************");
        System.out.println(ppriv.toString());
        System.out.println("Ganancias: "+ppriv.mostrarGananciasTotales());
        System.out.println("");
        //System.out.println(ppriv2.toString());
        //System.out.println("Ganancias: "+ppriv2.mostrarGananciasTotales());
        
        System.out.println("* LISTADO DE EXCEPCIONES: ");
        printListaExcepciones();
        
    }
    
    /**
     * 
     * @param coches 
     */
    private static void cargaCoches(ArrayList<Coche> coches){
        //solo tengo dos coches electricos
        coches.add( new Coche("Fiat", "Linea", "7549HDW", false));
        coches.add(new Coche("Volvo", "modelo", "3549PDW", false));
        coches.add(new Coche("Citroen", "C3", "7549HDW", true));
        coches.add(new Coche("Mercedes", "X", "7549HDW", true));
        coches.add( new Coche("Audi", "Y", "7549HDW", true));
        
    }
    
    /**
     * 
     * @param p
     * @param coches 
     */
    private static void cargaCochesEnParking(Parking p, List<Coche> coches){
        for (int i = 0; i < coches.size(); i++) {
            try {
                p.addCoche(coches.get(i));
            } catch (ParkingCompletoException a) {
                excepciones.add(a);
            }
        }  
        
    }
    
    /**
     * 
     */
    public static void printListaExcepciones(){
        excepciones.forEach(System.out::println);
    }
    
}
