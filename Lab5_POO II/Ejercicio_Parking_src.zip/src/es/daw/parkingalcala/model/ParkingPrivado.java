package es.daw.parkingalcala.model;

/**
 *
 * @author melola
 */
public class ParkingPrivado extends Parking{
    private int numSocios;

    public ParkingPrivado(int numSocios, String nombre, String direccion, int capacidad) {
        super(nombre, direccion, capacidad);
        this.numSocios = numSocios;
    }
    
    // El número de socios se puede modificar en un futuro
    public void setNumSocios(int numSocios){
        this.numSocios = numSocios;
    }
    
    // Implementar el método abstracto
    public double mostrarGananciasTotales(){
        /*System.out.println("****************************************************************");
        System.out.println("[mostrarGananciasTotales] cantidadGanada: "+cantidadGanada);
        System.out.println("[mostrarGananciasTotales] numSocios: "+numSocios);
        System.out.println("[mostrarGananciasTotales] ganancias totales del parking privado: "+cantidadGanada / numSocios);
        System.out.println("****************************************************************");*/
        
        return cantidadGanada / numSocios;
    }

    @Override
    public String toString() {
        return "ParkingPrivado{ "+super.toString() + ", numSocios=" + numSocios + '}';
    }
    
    
}
