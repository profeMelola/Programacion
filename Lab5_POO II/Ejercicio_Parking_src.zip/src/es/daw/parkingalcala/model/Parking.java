package es.daw.parkingalcala.model;

import java.util.ArrayList;

import es.daw.parkingalcala.excepciones.ParkingCompletoException;

/**
 *
 * @author melola
 */
public abstract class Parking {

    private int id, capacidad;
    
    public static int contador = 0;
    public static int capacidadTotal = 0;
    public static int ocupacionTotal = 0;
    
    private String nombre, direccion;
    
    //private double cantidadGanada;
    protected double cantidadGanada;
    
    private ArrayList<Coche> coches;
    
    private final int tarifa = 5;
    
    public Parking(String nombre, String direccion, int capacidad) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.capacidad = capacidad;
        coches = new ArrayList<>(); //Al crear el parking creo la lista de coches
                                    //para que puedan aparcar los coches
        
        contador++;
        this.id = contador;
        capacidadTotal += capacidad;
        
    }

    /* Getter de todo, porsiaca */
    public int getId() {
        return id;
    }

    public static int getContador() {
        return contador;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public int getCapacidad() {
        return capacidad;
    }

    /*
    public double getCantidadGanada() {
        return cantidadGanada;
    }*/

    public ArrayList<Coche> getCoches() {
        return coches;
    }
    
    /* Setters de los tres parámetros del constructor */

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    // Método abstracto
    public abstract double mostrarGananciasTotales();

    /**
     * Método para obtener el % de ocupación local
     * @return 
     */
    private int getPorcentajeOcupacion(){
        /*System.out.println("[getPorcentajeOcupacion] num coches:"+coches.size());
        System.out.println("[getPorcentajeOcupacion] capacidad:"+capacidad);
        System.out.println("[getPorcentajeOcupacion] porcentaje:"+coches.size()*100/capacidad);*/
        return coches.size()*100/capacidad;
    }
    
    /**
     * Método para obtener el % de ocupación total
     * @return 
     */
    private int getPorcentajeOcupacionTotal(){
        /*System.out.println("[getPorcentajeOcupacionTotal]ocupacionTotal:"+ocupacionTotal);
        System.out.println("[getPorcentajeOcupacionTotal]capacidadTotal:"+capacidadTotal);*/
        return ocupacionTotal*100/capacidadTotal;
    }
    
    // MÉTODOS PÚBLICOS
    /**
     * 
     * @param c
     * @throws ParkingCompletoException 
     */
    public void addCoche(Coche c) throws ParkingCompletoException{
        // Si el número de coches es menor que la capacidad puedo meter otro coche
        if (coches.size() < capacidad) {
            coches.add(c);
            ocupacionTotal++;
            if (!c.isEsElectrico())
                cantidadGanada += tarifa;
        }
        else{
            ParkingCompletoException e = new ParkingCompletoException(nombre, capacidad);
            throw e;
        }
    }

    /**
     * 
     * @param posicion 
     */
    public boolean deleteCoche(int posicion){
    //public void deleteCoche(int posicion){
        /*Coche c = coches.get(posicion);
        if (!c.isEsElectrico())
            cantidadGanada -= tarifa;*/
        
        // Comprobar que la posicion es correcta
        if (posicion < coches.size()){
            coches.remove(posicion);
            ocupacionTotal--;
            return true;
        }else return false;
        
    }
    
    /**
     * 
     * @return 
     */
    private int getNumero_Coches(){
        return coches.size();
    }
    
    /**
     * mostrarCoches
     * @return 
     */
    public String mostrarCoches(){
        StringBuilder sb = new StringBuilder();
        for (Coche c:coches) sb.append(c.toString()+"\n");
        return sb.toString();
    }
    
    /**
     * mostrarCochesElectricos
     * @return 
     */
    public String mostrarCochesElectricos(){
        StringBuilder sb = new StringBuilder();
        for (Coche c:coches) {
            if (c.isEsElectrico())
                sb.append(c.toString()+"\n");
        }
        return sb.toString();
    }
         
    /**
     * getNumCochesElectricos
     * @return 
     */
    public int getNumCochesElectricos(){
        int cont=0;
    
        for (Coche c: coches) if (c.isEsElectrico()) cont++;
            
        return cont;
    }
    
    @Override
    public String toString() {
        String mensaje = String.format("El parking %s con id %d"
                + ", situado en %s, cuenta con una capacidad de %d coches."
                + "\nAhora están aparcados %d coches."
                + "\nEl porcentaje de ocupación es del %d %%."
                + "\n\nEn Alcalá hay %d plazas disponibles."
                + "\nEl porcentaje de ocupación total es del %d %% ."
                + "\n"
                + "Estos son los coches aparcados: %s"
                + "\nDe los cuales solo son eléctricos: %s"
                + "\n------------------------------------",
                nombre,
                id,
                direccion,
                capacidad, coches.size(),getPorcentajeOcupacion(),capacidadTotal,getPorcentajeOcupacionTotal(),
                mostrarCoches(),mostrarCochesElectricos());
        return mensaje;
    }
    
    
    
    
}
