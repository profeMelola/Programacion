package es.daw.parkingalcala.model;

/**
 *
 * @author melola
 */
public class ParkingPublico extends Parking{
    private int numTrabajadoresDiscapacitados;

    public ParkingPublico(int numTrabajadoresDiscapacitados, String nombre, String direccion, int capacidad) {
        super(nombre, direccion, capacidad);
        this.numTrabajadoresDiscapacitados = numTrabajadoresDiscapacitados;
    }
    
    // Doy por hecho que el numTrabajadoresDiscapacitados lo podré modificar
    // en un futuro
    public void setTrabajadoresDiscapacitados(){
        this.numTrabajadoresDiscapacitados = numTrabajadoresDiscapacitados;
    }
    
    
    // Implementar el método abstracto
    @Override
    public double mostrarGananciasTotales(){
        /*System.out.println("****************************************************************");
        System.out.println("[mostrarGananciasTotales] cantidadGanada: "+cantidadGanada);
        System.out.println("[mostrarGananciasTotales] numTrabajadoresDiscapacitados: "+numTrabajadoresDiscapacitados);
        System.out.println("[mostrarGananciasTotales] ganancias totales del parking público: "+(cantidadGanada + (numTrabajadoresDiscapacitados *250)));
        System.out.println("****************************************************************");*/
        return cantidadGanada + (numTrabajadoresDiscapacitados *250);
    }

    @Override
    public String toString() {
        return "ParkingPublico{ " +super.toString() +", numTrabajadoresDiscapacitados=" + numTrabajadoresDiscapacitados + '}';
    }
    
    
    
}
