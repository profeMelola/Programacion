/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package reto_camelcase;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author melola
 */
public class CamelCaseTest {
    
    public CamelCaseTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of convert2CamelCaseSplit method, of class CamelCase.
     */
    @Test
    public void testConvert2CamelCaseSplit() {
        System.out.println("convert2CamelCaseSplit");
        String s = "The-stealth_warrior";
        String separador = "-|_";
        String expResult = "TheStealthWarrior";
        String result = CamelCase.convert2CamelCaseSplit(s, separador);
        //assertEquals(expResult, result);
        assertTrue(expResult.equals(result));
    }

/**
     * Test of convert2CamelCaseST method, of class CamelCase.
     */
    @Test
    public void testConvert2CamelCaseST() {
        System.out.println("convert2CamelCaseST");
        String cadena = "The_stealth_warrior";
        String separador = "_";
        String expResult = "TheStealthWarrior";
        String result = CamelCase.convert2CamelCaseST(cadena, separador);
        //assertEquals("TheStealthWarrior",expResult, result);
        assertTrue(expResult.equals(result));
    }

    /**
     * Test of convert2CamelCaseIndexOf method, of class CamelCase.
     */
    @Test
    public void testConvert2CamelCaseIndexOf() {
        System.out.println("convert2CamelCaseIndexOf");
        String cadena = "the_stealth_warrior";
        String separador = "_";
        String expResult = "theStealthWarrior";
        String result = CamelCase.convert2CamelCaseIndexOf(cadena, separador);
        //assertEquals("theStealthWarrior",expResult, result);
        assertTrue(expResult.equals(result));
    }
     
}
