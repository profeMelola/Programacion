
package reto_camelcase;

import java.util.StringTokenizer;

/**
 *
 * @author melol
 */
public class CamelCase {
/**
     * convert2CamelCaseSplit
     * @param s
     * @return 
     */
    public static String convert2CamelCaseSplit(String s, String separador) {
        StringBuilder resultado = new StringBuilder();
        String partes[] = s.split(separador);
        // pasar a mayúscula de la primera letra
        resultado.append(partes[0]);
        
        for(int i = 1; i<partes.length;i++){
            // para cada una de las palabras sustituyo la primera letra y las demás las añado al StringBuilder
            resultado.append(String.valueOf(partes[i].charAt(0)).toUpperCase());
            
            // la conversión por (char) no funciona cuando se invoca desde tests
           //resultado.append((char)(partes[i].charAt(0)-32));  
           
            for(int a=1; a<partes[i].length(); a++){
                resultado.append(partes[i].charAt(a));
            }
            
            
        }
        
      
        return resultado.toString();
    }    
    
    /**
     * Con StringTokenizer
     * @param s
     * @param separador
     * @return 
     */
    public static String convert2CamelCaseST(String cadena, String separador) {
        StringBuilder resultado = new StringBuilder();
        StringTokenizer st = new StringTokenizer(cadena, separador);
        int i=0;
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            if (i==0) resultado.append(token);
            else {
                resultado.append(String.valueOf(token.charAt(0)).toUpperCase());
                resultado.append(token.substring(1));
            }
            i++;
        }
        return resultado.toString();
        
    }
    
    /**
     * convert2CamelCaseIndexOf
     * @param cadena
     * @param separador
     * @return 
     */
    public static String convert2CamelCaseIndexOf(String cadena, String separador){
        StringBuilder resultado = new StringBuilder();
        resultado.append(cadena.charAt(0)); // añado el primera carácter. Me da igual que esté en may o en min
        int end = cadena.indexOf(separador); // busco el primer separador 
        
        String aux = "";
        int init = 1;
        String firstLetter = "";
        
        //Mientras se encuentre el separador en la cadena original.
        while(end != -1){
            aux = cadena.substring(init,end);
            if (init == 1){
                resultado.append(aux);
                aux = cadena.substring(end+1);
            }
            else{
                firstLetter = String.valueOf(aux.charAt(0)).toUpperCase();
                resultado.append(firstLetter.toUpperCase());
                resultado.append(cadena.substring(init+1,end));
                //aux = aux.substring(end+1);
            }
            init = end+1;
            end = cadena.indexOf(separador,init);
            System.out.println("********************************");
            System.out.println("sb: "+resultado.toString());
            System.out.println("init: "+init);
            System.out.println("end: "+end);
            System.out.println("********************************");
        }
        //Queda el último token por meter
        firstLetter = String.valueOf(cadena.charAt(init)).toUpperCase();
        resultado.append(firstLetter.toUpperCase());
        resultado.append(cadena.substring(init+1));
        return resultado.toString();
        
    }    
}
