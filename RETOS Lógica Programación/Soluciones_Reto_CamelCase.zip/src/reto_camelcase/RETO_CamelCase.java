/*
 * Programa un método para que convierta las palabras delimitadas por guiones o guiones bajos en mayúsculas y minúsculas.
 * La primera palabra dentro de la salida debe estar en mayúsculas solo si la palabra original estaba en mayúsculas (conocido como Upper Camel Case)
 * Ejemplos:
 * "the-stealth-warrior" se convierte en "theStealthWarrior"
 * "The_Stealth_Warrior" se convierte en "TheStealthWarrior"
 */
package reto_camelcase;

import java.util.StringTokenizer;

/**
 *
 * @author melol
 */
public class RETO_CamelCase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cadena = "the-stealth-warrior";
        String rdo = "";
        
        System.out.println("[SPLIT] Cadena en Camel Case:"+CamelCase.convert2CamelCaseSplit(cadena,"_|-"));
        System.out.println("[TOKENIZER] Cadena en Camel Case:"+CamelCase.convert2CamelCaseST(cadena,"-"));
        
        
        System.out.println("*********** PRUEBAS CON INDEXOF Y SUBSTRING *************");
        System.out.println("CASO 1: CADENA ORIGINAL: "+cadena);
        rdo = CamelCase.convert2CamelCaseIndexOf(cadena,"-");
        System.out.println("CAMEL CASE: "+rdo);
        
        cadena = "The_Stealth_Warrior";
        System.out.println("CASO 2: CADENA ORIGINAL: "+cadena);
        rdo = CamelCase.convert2CamelCaseIndexOf(cadena,"_");
        System.out.println("CAMEL CASE: "+rdo);
        System.out.println("*********************************************************");
        
        
        

    }
    
    
    
}
