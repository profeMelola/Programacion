
package camelcase;

import javax.xml.transform.Source;


public class CamelCase {

  
    public static void main(String[] args) {
        // TODO code application logic here
        
          String texto = "hola_esta_es_una_clase_de_programacion";
          String texto2 = "Ejemplo-camel-case";
    
         
         pintaPalabraCamelCase(texto,'_');
         pintaPalabraCamelCase(texto2,'-');
         
         
    }

    public static void pintaPalabraCamelCase(String texto,char caracter){
        
        char [] pasaChar = texto.toCharArray();
   
        String Auxiliar="";
        int param = (int)caracter;

        
        for(int i = 0 ; i < pasaChar.length ; i ++){
            
            int numero =(int)pasaChar[i];

            if(numero!=param){
                Auxiliar+=pasaChar[i];   
            }else{
                i++;
                Auxiliar+=String.valueOf(pasaChar[i]).toUpperCase();
                }
            
            
        }
        System.out.println("");
        System.out.println(Auxiliar);
    }
    
}
