package upper.camel.pkgcase;

/**
 *
 * @author alumnot
 */
public class UpperCamelCase {

    public static void main(String[] args) {
        String cadena="The_stealth_warrior";
        String[] partes=cadena.split("_");
        for(int i=1;i<partes.length;i++){
            char a=partes[i].charAt(0);
            char b=partes[i].toUpperCase().charAt(0);
            partes[i]=partes[i-1]+partes[i].replace(a, b);
        }
        
        System.out.println(partes[partes.length-1]);
    }
    
}
