public class Pascal {

    public static void main(String[] args)
    {      
        TrianguloPascal.pascal(5);
    }
}
