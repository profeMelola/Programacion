
import java.util.Arrays;

/* Debes completar  el método pascal (int depth), que devolverá el triángulo en forma de matriz

pascal(5) -> [ [1], [1,1], [1,2,1], [1,3,3,1], [1,4,6,4,1] ]

 */

public class TrianguloPascal {

    public static int[][] pascal(int n) {

        // completa el código aquí
        // el ejemplo retorna el resultado para depth 1
        //return new int[][] { { 1 } };
     
        
        int[][] matriz = new int[n][];
        matriz[0] = new int[]{1};
        System.out.println(String.format("%5d", matriz[0][0]));
        for (int k = 1; k < matriz.length; k++) {
            matriz[k] = new int[k + 1];
            matriz[k][0] = matriz[k][k] = 1;
            System.out.print(String.format("%5d", 1));
            for (int i = 1; i < k; i++) {
                matriz[k][i] = matriz[k - 1][i - 1] + matriz[k - 1][i];
                System.out.print(String.format("%5d", matriz[k][i]));
            }
            System.out.println(String.format("%5d", 1));
        }
        
        for (int i=0; i<matriz.length;i++)
            System.out.println(Arrays.toString(matriz[i]));
        
        return matriz;
    }

}
