package es.daw.repaso.model;

/**
 *
 * @author melola
 */
public class Alumno extends Persona{
    private int curso;
    
    public Alumno(String nombre, String apellido1, String apellido2, String DNI, int edad) {
        super(nombre, apellido1, apellido2, DNI, edad);
    }

    public Alumno(String nombre, String apellido1, String apellido2, String DNI, int edad, int curso) {
        super(nombre, apellido1, apellido2, DNI, edad);
        this.curso = curso;
    }
    
}
