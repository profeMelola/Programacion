package es.daw.repaso.model;

import java.util.ArrayList;

/**
 *
 * @author melola
 */
public class Aula {
    private String curso, siglas, grado, centro;
    private ArrayList<Alumno> listaAlumnos;

    public Aula(String curso, String siglas, String grado, String centro) {
        this.curso = curso;
        this.siglas = siglas;
        this.grado = grado;
        this.centro = centro;
        this.listaAlumnos = new ArrayList<Alumno>();
    }
    
    //getListaAlumnos
    //setListaAlumnos
    
            
}
