package es.daw.repaso.main;

import es.daw.repaso.dao.AlumnoDAOImpl;
import es.daw.repaso.model.Alumno;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author melola
 */
public class Main {
    public static void main(String[] args) {
        
        //Pendiente crear Aula como Dios manda
        
        AlumnoDAOImpl alumnoDAO = new AlumnoDAOImpl();
        
        ArrayList<Alumno> listaAlumnos = alumnoDAO.select(); //Me da igual de donde vengan los datos... sé que recibo una colección de Alumnos

        System.out.println("*Lista de alumnos sin ordenar:");
        for(Alumno a: listaAlumnos)
            System.out.println(a);
        
        System.out.println("*Lista de alumnos ordenados por defecto:");
        Collections.sort(listaAlumnos);
        for(Alumno a: listaAlumnos)
            System.out.println(a);
        
    }
}
