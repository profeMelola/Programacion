package es.daw.repaso.dao;

import es.daw.repaso.model.Alumno;
import java.util.ArrayList;

/**
 *
 * @author melola
 */
public class AlumnoDAOImpl implements AlumnoDAO{

    // COMO SI FUERA LA BB.DD
    private ArrayList<Alumno> listaAlumnos = new ArrayList<>();
    
    public AlumnoDAOImpl(){
        // Simula que la tabla tiene datos... 
        listaAlumnos.add(new Alumno("MariLuz","Elola","Rubio","88888888V",46));
        listaAlumnos.add(new Alumno("Otro","Antón","Berlín","98999999F",52));
        listaAlumnos.add(new Alumno("Antonio","Barcelona","Cáceres","11999999F",28));
    }
    
    @Override
    public ArrayList<Alumno> select() {
        return listaAlumnos;
        
    }

    @Override
    public Alumno select(String dni) {
        return null;
    }
    
}
