package es.daw.repaso.dao;

import es.daw.repaso.model.Alumno;
import java.util.ArrayList;

/**
 *
 * @author melola
 */
public interface AlumnoDAO {

    public ArrayList<Alumno> select();
    public Alumno select(String dni);
    
    /*
    public void delete(Alumno a);
    public void delete(int posicion);
    
    public void update(Alumno a);
    public void update(int posicion);
    
    public void insert(Alumno a);
    public void insert(int posicion);
    */
    
}
