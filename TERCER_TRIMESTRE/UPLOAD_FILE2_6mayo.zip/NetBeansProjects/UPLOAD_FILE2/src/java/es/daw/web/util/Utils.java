package es.daw.web.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;

/**
 *
 * @author daw1a
 */
public class Utils {

    /**
     * Método para listar el contenido de un directorio
     * Usando java.io o java.nio
     * @param path
     * @param type is true es java.io
     * @return cadena de texto con todo formateado
     * @throws IOException 
     */
    public static String listDir(String path,Boolean type) throws IOException{
        StringBuilder sb = new StringBuilder();
        
        if (type){
            //usando java.io
            File miCarpeta = new File(path);
            File[] listaFicheros = miCarpeta.listFiles();
            for (int i=0; i< listaFicheros.length; i++)
                sb.append(listaFicheros[i].getName()+"<br>");
        }else{
            //usando java.nio + arrow
            //Files.list(Paths.get(path)).forEach( f -> sb.append(f.getFileName()+"<br>"));
            
            Files.list(Paths.get(path))
                    .filter(Files::isDirectory)
                    .sorted(Comparator.reverseOrder())
                    .forEach( f -> sb.append(f.getFileName()+"<br>"));
            
            
        }
        
        
        return sb.toString();
    }
    
}
