package es.daw.web;

import es.daw.web.util.Utils;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author daw1a
 */
@MultipartConfig
@WebServlet(name = "UploadServlet", urlPatterns = {"/UploadServlet"})
public class UploadServlet extends HttpServlet {
    
    // Directorio donde se van a subir las fotos
    private static final String UPLOAD_DIR = "uploads";
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // -------------------------------------
        // 1. RECOGER LOS PARÁMETROS
        // Preparar los datos para posteriomente crear el objeto Usuario
        System.out.println("********* PARÁMETROS *************");
        String name = request.getParameter("name");
        System.out.println("name:"+name);
        String email = request.getParameter("email");
        System.out.println("email:"+email);
        String date = request.getParameter("date");
        System.out.println("date:"+date); //2022-05-06
        LocalDate ldate = LocalDate.parse(date);
        System.out.println("ldate:"+ldate);
        System.out.println("************************************");
        
        // ---------------------------------------
        // 2. REDIRIGIR A UNA PÁGINA HTML DE SALIDA 
        if (!name.equalsIgnoreCase("admin"))
            response.sendRedirect("error.html");
        else{
            // ---------------------------------------

            // -----------------------------------
            // 3. TRABAJANDO CON EL FILE DE SUBIDA
            //Para obtener la ruta al directorio de despliegue de mi proyecto
            String applicationPath = request.getServletContext().getRealPath("");
            //Subdirectorio de descarga en el servidor de las fotos
            String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;

            Path p = Paths.get(uploadFilePath);

            if (!Files.exists(p))
                Files.createDirectory(p);

            // Obtener el contenido del input file (memoria)
            Part archivo = request.getPart("photo");

            // Trazas para mostrar info del fichero subido       
            System.out.println("*Info del fichero subido en:"+applicationPath);
            System.out.println("contenttype:"+archivo.getContentType());
            System.out.println("name:"+archivo.getName());
            System.out.println("size:"+archivo.getSize());

            String nombre = archivo.getSubmittedFileName();
            System.out.println("submittedFileName:"+nombre);

            // Crear el fichero en disco
            archivo.write(uploadFilePath + File.separator + nombre);

            // ---------------------------------------
            // 4. Trabajando con atributos del request
            request.setAttribute("message", "Fichero "+nombre+" subido correctamente en "+uploadFilePath);
            request.setAttribute("directorio", applicationPath);
            request.setAttribute("listado",Utils.listDir(applicationPath,false));
            
            //un atributo que uso para comunicar los dos servlets
            request.setAttribute("pathFichero", uploadFilePath + File.separator + nombre);

            //------------------
            //5 . MI PRIMER JSP (no uso el PrinWriter)
            getServletContext().getRequestDispatcher("/response.jsp").forward(request, response);
            
            // ---------------------------
            //6. REDIRIGIR A OTRO SERVLET
            //getServletContext().getRequestDispatcher("/ImageServlet").forward(request, response);
            
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
