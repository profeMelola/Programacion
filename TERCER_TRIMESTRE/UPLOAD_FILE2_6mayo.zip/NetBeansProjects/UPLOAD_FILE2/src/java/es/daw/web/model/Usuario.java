package es.daw.web.model;

/**
 *
 * @author daw1a
 */
public class Usuario {
    
}
