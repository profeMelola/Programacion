package es.daw.web.util;

import es.daw.web.model.Usuario;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;

/**
 *
 * @author daw1a
 */
public class Utils {

    /**
     * Método para listar el contenido de un directorio
     * Usando java.io o java.nio
     * @param path
     * @param type is true es java.io
     * @return cadena de texto con todo formateado
     * @throws IOException 
     */
    public static String listDir(String path,Boolean type) throws IOException{
        StringBuilder sb = new StringBuilder();
        
        if (type){
            //usando java.io
            File miCarpeta = new File(path);
            File[] listaFicheros = miCarpeta.listFiles();
            for (int i=0; i< listaFicheros.length; i++)
                sb.append(listaFicheros[i].getName()+"<br>");
        }else{
            //usando java.nio + arrow
            //Files.list(Paths.get(path)).forEach( f -> sb.append(f.getFileName()+"<br>"));
            
            Files.list(Paths.get(path))
                    //.filter(Files::isDirectory)
                    .sorted(Comparator.reverseOrder())
                    .forEach( f -> sb.append(f.getFileName()+"<br>"));
            
            
        }
        
        
        return sb.toString();
    }
    
    
    public static void serializar (Usuario usuario) throws FileNotFoundException, IOException{
        try ( ObjectOutputStream salida = new ObjectOutputStream(
                new FileOutputStream(usuario.getNombre()+".dat"))){
            salida.writeObject(usuario);
            //salida.close();
        }
    }
    
    public static Usuario desSerializar(Usuario usuario) throws IOException, ClassNotFoundException{
        
        try( ObjectInputStream entrada = new ObjectInputStream(
            new FileInputStream(usuario.getNombre()+".dat"))){
            
            Usuario newUser = (Usuario)entrada.readObject();
            //entrada.close();
            return newUser;
        }
    }
    
    
}
