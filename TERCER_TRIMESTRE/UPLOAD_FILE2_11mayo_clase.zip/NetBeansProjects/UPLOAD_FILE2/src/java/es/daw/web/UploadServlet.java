package es.daw.web;

import es.daw.web.bd.DaoUsuario;
import es.daw.web.model.Usuario;
import es.daw.web.util.Utils;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author daw1a
 */
@MultipartConfig
@WebServlet(name = "UploadServlet", urlPatterns = {"/UploadServlet"})
public class UploadServlet extends HttpServlet {
    
    // Directorio donde se van a subir las fotos
    private static final String UPLOAD_DIR = "uploads";
    
    private DaoUsuario daoUsuario = null;
    
    private String messageError  = "";
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        // -------------------------------------
        // 1. RECOGER LOS PARÁMETROS
        // Preparar los datos para posteriomente crear el objeto Usuario
        System.out.println("********* PARÁMETROS *************");
        String name = request.getParameter("name");
        System.out.println("name:"+name);
        String email = request.getParameter("email");
        System.out.println("email:"+email);
        String date = request.getParameter("date");
        System.out.println("date:"+date); //2022-05-06
        LocalDate ldate = LocalDate.parse(date);
        System.out.println("ldate:"+ldate);
        String opcion = request.getParameter("opcion");
        System.out.println("opcion:"+opcion);
        
        //System.out.println("opciones:");
        //String opcion="kk";
        //String[] opcion2 = request.getParameterValues("opcion");
        //Arrays.asList(opcion2).forEach(System.out::println);
        
        
        System.out.println("************************************");
        
        // ---------------------------------------
        // 2. REDIRIGIR A UNA PÁGINA HTML DE SALIDA 
        //if (!name.equalsIgnoreCase("admin"))
        //    response.sendRedirect("error.html");
        //else{
            // ---------------------------------------
            
        // -----------------------------
        // Cargar el JavaBean
        Usuario user = new Usuario();
        user.setNombre(name);
        user.setEmail(email);
        user.setFecha(ldate);
        // ---------------------------
        
        try{
            // Obtener el DAO
            daoUsuario = DaoUsuario.getInstance();
            switch (opcion){
                case "insertar":
                    // -----------------------------------
                    // 3. TRABAJANDO CON EL FILE DE SUBIDA
                    //Para obtener la ruta al directorio de despliegue de mi proyecto
                    String applicationPath = request.getServletContext().getRealPath("");
                    //Subdirectorio de descarga en el servidor de las fotos
                    String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;

                    Path p = Paths.get(uploadFilePath);

                    if (!Files.exists(p))
                        Files.createDirectory(p);

                    // Obtener el contenido del input file (memoria)
                    Part archivo = request.getPart("photo");

                    // Trazas para mostrar info del fichero subido       
                    System.out.println("*Info del fichero subido en:"+applicationPath);
                    System.out.println("contenttype:"+archivo.getContentType());
                    System.out.println("name:"+archivo.getName());
                    System.out.println("size:"+archivo.getSize());

                    String nombre = archivo.getSubmittedFileName();
                    System.out.println("submittedFileName:"+nombre);

                    // Crear el fichero en disco
                    archivo.write(uploadFilePath + File.separator + nombre);
            
                    // Cargo en usuario el atributo path_foto
                    user.setPath_foto(uploadFilePath + File.separator + nombre);
                    
                    // Trabajando con atributos del request
                    request.setAttribute("message", "Fichero "+nombre+" subido correctamente en "+uploadFilePath);
                    request.setAttribute("directorio", applicationPath);
                    request.setAttribute("listado",Utils.listDir(applicationPath,false));
                    
                    
                    // Conexión a la B.D
                    daoUsuario.insert(user);
                    messageError="Se ha realizado la operación de INSERT satisfactoriamente!!!!";
                    
                    // Pruebas de Serialización
                    // Primero, serializo (creo fichero binario en directorio default )
                    Utils.serializar(user);
                    // Segundo, vuelvo a obtener el objeto usuario del fichero binario 
                    Usuario userDes = Utils.desSerializar(user);
                    request.setAttribute("usuario", userDes.toString());
                    
                    break;
                case "listar":
                    break;
                case "actualizar":
                    break;
                    
            }
        }catch(SQLException e){
            e.printStackTrace();
            messageError = "[SQLException] Ha fallado la operación <"+opcion+"> contra la B.D";
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UploadServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        request.setAttribute("messageError", messageError);
            

        //------------------
        //5 . MI PRIMER JSP (no uso el PrinWriter)
        getServletContext().getRequestDispatcher("/responseInsert.jsp").forward(request, response);

        // ---------------------------
        //6. REDIRIGIR A OTRO SERVLET
        //un atributo que uso para comunicar los dos servlets
        //request.setAttribute("pathFichero", uploadFilePath + File.separator + nombre);
        //getServletContext().getRequestDispatcher("/ImageServlet").forward(request, response);
            
            
        //}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
