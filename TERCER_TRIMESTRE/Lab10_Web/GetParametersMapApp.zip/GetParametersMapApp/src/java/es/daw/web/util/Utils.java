package es.daw.web.util;

import java.io.BufferedWriter;
import java.io.IOException;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 *
 * @author daw1a
 */
public class Utils {

    /**
     * Método que pinta por consola (del servidor Wildfly) los parámetros 
     * recibidos por el Servlet en el request (petición HTTP)
     * @param propiedades 
     */
    public static void printRequestParameters(Map<String,String[]> propiedades) {

        // PRIMERA FORMA: Set con iterator
        System.out.println("* PRIMERA FORMA:");
        Set<Entry<String, String[]>> set = propiedades.entrySet();
        Iterator<Entry<String, String[]>> it = set.iterator();
        while (it.hasNext()) {
            Entry<String, String[]> entry = it.next();

            System.out.println("KEY:" + entry.getKey());
            for (String i : entry.getValue()) {
                System.out.println(i);
            }
        }
        
        // SEGUNDA FORMA: Set con bucle simple
        System.out.println("* SEGUNDA FORMA:");
        Set<Entry<String, String[]>> set2 = propiedades.entrySet();
        for (Entry<String, String[]> entry : set2) {
            System.out.println("KEY:" + entry.getKey());
            for (String i : entry.getValue()) {
                System.out.println(i);
            }
        }
        
     

        // TERCERA FORMA
        System.out.println("* TERCERA FORMA:");
        for (String key : propiedades.keySet()) {
            String[] value = propiedades.get(key);
            //System.out.printf("%s %s %n", key, propiedades.get(key));
            System.out.printf("%s %s %n", key, value[0]);
            //System.out.println(key+" "+value[0]);
        }
        
        // CUARTO FORMA
        /*System.out.println("* CUARTA FORMA:");
        printHash(propiedades);*/
        
        

    }
    
    /**
     * Método que crea un fichero de propiedades en el directorio de ejecución
     * de Wildfly (/opt/wildfly/bin)
     * @param propiedades Map con los pares nombre/valor
     * @param nombreFichero nombre sin path, solo el nombre, por ejemplo inputs.properties
     * @return
     * @throws IOException 
     */
    public static boolean createPropertiesFile(Map<String,String[]> propiedades, String nombreFichero) throws IOException{
        
        Path prop = Paths.get(nombreFichero);//"inputs.properties"
        
        if (Files.notExists(prop)){
            System.out.println("[INFO] El fichero de propiedades no existe.");
            Files.createFile(prop);
        }
        
        try (BufferedWriter bw = Files.newBufferedWriter(prop, Charset.forName("UTF-8"))){
            System.out.println("************ Escribiendo en el fichero");
            for (String key : propiedades.keySet()) {
                String[] value = propiedades.get(key);
                //System.out.printf("%s %s %n", key, value[0]);
                System.out.println("************"+key+":"+value[0]);
                bw.write(key+":"+value[0]);
                bw.newLine();
            }
        }catch(IOException e){
            System.err.println("[ERROR] Error al escribir el fichero de propiedades!!!");
            throw e;
        }
        //finally{ //No es necesario porque estoy haciendo el try catch with resources
            //bw.close();
        //}
        System.out.println("****************** Se ha terminado de escribir en el fichero!!!!!!");
        return true;
        
    }
    
    /**
     * printHash (MÉTODO GENÉRICO)
     * ¿Qué problema encontráis al usar este método genérico para pintar el Map
     * devuelto por request.getParameterMap()???????????????????
     * @param <K>
     * @param <V>
     * @param map 
     */
    private static <K,V> void printHash(Map<K, V> map){
        System.out.println("\t-------------- "+map.size()+"---------------------");
        map.forEach((k, v) -> {
            System.out.println("\tkey: " + k);
            System.out.println("\tvalue: " + v);
            System.out.println("\t--------------------------------------------------");
        });
        
    }     

}
