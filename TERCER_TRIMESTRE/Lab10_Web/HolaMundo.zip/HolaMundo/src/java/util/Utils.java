package util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 *
 * @author daw1a
 */
public class Utils {

    public static void printRequestParameters(Map<String,String[]> propiedades) {

        
        // PRIMERA FORMA
        System.out.println("* PRIMERA FORMA:");
        Set<Entry<String, String[]>> set = propiedades.entrySet();
        Iterator<Entry<String, String[]>> it = set.iterator();
        while (it.hasNext()) {
            Entry<String, String[]> entry = it.next();

            System.out.println("KEY:" + entry.getKey());
            for (String i : entry.getValue()) {
                System.out.println(i);
            }
        }
        

        // SEGUNDA FORMA
        System.out.println("* SEGUNDA FORMA:");
        for (String key : propiedades.keySet()) {
            String[] value = propiedades.get(key);
            //System.out.printf("%s %s %n", key, map.get(key));
            System.out.printf("%s %s %n", key, value[0]);
        }
        
        // TERCERA FORMA
        System.out.println("* TERCERA FORMA:");
        printHash(propiedades);
        
        

    }
    
    /**
     * printHash (MÉTODO GENÉRICO)
     * @param <K>
     * @param <V>
     * @param map 
     */
    private static <K,V> void printHash(Map<K, V> map){
        System.out.println("\t-------------- "+map.size()+"---------------------");
        map.forEach((k, v) -> {
            System.out.println("\tkey: " + k);
            System.out.println("\tvalue: " + v);
            System.out.println("\t--------------------------------------------------");
        });
        
    }    
    
    public static boolean createPropertiesFile(Map<String,String[]> propiedades) throws IOException{
        Path prop = Paths.get("inputs.properties");
        if (Files.notExists(prop)){
            System.out.println("[INFO] El fichero de propiedades no existe.");
            Files.createFile(prop);
        }
        try (BufferedWriter bw = Files.newBufferedWriter(prop, Charset.forName("UTF-8"))){
            System.out.println("************ Escribiendo en el fichero");
            for (String key : propiedades.keySet()) {
                String[] value = propiedades.get(key);
                //System.out.printf("%s %s %n", key, value[0]);
                System.out.println("************"+key+":"+value[0]);
                bw.write(key+":"+value[0]);
                bw.newLine();
            }
        }catch(IOException e){
            System.err.println("[ERROR] Error al escribir el fichero de propiedades!!!");
            throw e;
        }
        //finally{ //No es necesario porque estoy haciendo el try catch with resources
            //bw.close();
        //}
        System.out.println("****************** Se ha terminado de escribir en el fichero!!!!!!");
        return true;
        
    }

}
