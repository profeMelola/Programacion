package es.daw.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author daw1a
 */
@WebServlet(name = "HolaMundo2", urlPatterns = {"/HolaMundo2"})
public class HolaMundo2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        // -----------------------------
        // Aquí método mi código java.....
        
        // ----------------------------
        
        response.setContentType("text/html;charset=UTF-8");
        
        /*
        
        // try ... catch tradicional
        PrintWriter out2 = null;
        
        try{
            out2 = response.getWriter();
            out2.println("<!DOCTYPE html>");
            out2.println("<html>");
            out2.println("<head>");
            out2.println("<title>Servlet HolaMundo2</title>");            
            out2.println("</head>");
            out2.println("<body>");
            out2.println("<h1>Servlet HolaMundo2 at " + request.getContextPath() + "</h1>");
            out2.println("</body>");
            out2.println("</html>");
        }catch(IOException e){
            e.printStackTrace();
            System.err.println("ERROR escribiendo en el PrintWriter....");
            //throw e;
        }
        finally{
            if (out2 != null){
                out2.close();
            }
        }
        */
        
        try ( PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet HolaMundo2</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet HolaMundo2 at " + request.getContextPath() + "</h1>");
            out.println("<h2>HE CAMBIADO POR PRIMERA VEZ MI SERVLET!!!!!</h2>");
            out.println("</body>");
            out.println("</html>");
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
