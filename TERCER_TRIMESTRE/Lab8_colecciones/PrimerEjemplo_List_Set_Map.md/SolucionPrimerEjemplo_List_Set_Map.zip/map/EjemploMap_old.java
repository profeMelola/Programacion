/**
 *
 */
package map;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import modelo.Persona;

public class EjemploMap {

    static Map<String, Persona> agenda = new HashMap<>();
    
    /**
     * @param args
     */
    public static void main(String[] args) {

        //Insertamos los pares clave, valor
        //Simulando una agenda de teléfono: clave el teléfono y el valor la persona con su datos
        agenda.put("954000001", new Persona("11111111A", "Pepe", "Perez", LocalDate.of(1990, 1, 2)));
        agenda.put("954000004", new Persona("44444444D", "María", "López", LocalDate.of(1993, 4, 5)));
        agenda.put("954000002", new Persona("22222222B", "Juan", "Martínez", LocalDate.of(1991, 2, 3)));
        agenda.put("954000003", new Persona("33333333C", "Ana", "Ramírez", LocalDate.of(1992, 3, 4)));
        
        //Si insertamos un elemento con la misma clave, lo sustituimos
        //No podemos tener dos claves que tenga valores diferentes
        agenda.put("954000004", new Persona("56789012E", "Martín", "García", LocalDate.of(1990, 12, 15)));

        //La forma más normal de recorrer un Map es tomar su conjunto de claves, iterar por ellas, y
        //para cada una de ellas, obtener el valor.
        for (String key : agenda.keySet()) {
            //System.out.printf("%s %s %n", key, agenda.get(key));
            System.out.println("* Clave:"+key);
            System.out.println("* Valor:"+agenda.get(key));
        }
        
        /*
        // Si falla el primero, el segundo no se busca
        try{
            System.out.println("Persona con teléfono 8888888: "+searchPersonByPhone("8888888"));
            System.out.println("Persona con teléfono 954000002: "+searchPersonByPhone("954000002"));
        }catch(Exception e){
            System.out.println(e.getMessage());
        }*/

        try{
            System.out.println("Persona con teléfono 8888888: "+searchPersonByPhone("8888888"));
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        try{
            System.out.println("Persona con teléfono 954000002: "+searchPersonByPhone("954000002"));
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        /*
        for (int i =0; i < ...; i++){
            try{
                String telef = arrayInventado[i];
                System.out.println("Persona con teléfono 954000002: "+searchPersonByPhone(telef));
            }catch(Exception e){
                System.out.println(e.getMessage());
            }
        
        }*/
        
        Persona martin = new Persona("56789012E", "Martín", "García", LocalDate.of(1990, 12, 15));
        System.out.println("Teléfono de Martín: "+searchPhoneByPerson(martin));
        
        updatePhone(martin,"1111101111");
        System.out.println("Agenda después de cambiar el teléfono de Martín por 11110111");
        printMap();
        
        System.out.println("FINNNNNNNNNNNNNNNNNNNNNN");

    }
    
    /*
     AMPLICACIÓN DEL EJERCICIO
     - Método para buscar los datos de una persona a través del teléfono.
     - Método para buscar el teléfono de una persona.
     - Método para modificar el teléfono de una pesona en concreto.
     - Método para dar de alta una nueva Persona con su teléfono en la agenda
     - Método para borrar una persona concreta de la agenda.
     - Método para devolver la lista de personas con su teléfono ordenados por DNI
    */
    public static void printMap(){
    // También podemos recorrer el HashMap con un estilo "más lambda"
        agenda.forEach((k,v) -> {System.out.println("clave:"+k+"\n");
                            System.out.println("valor:"+v+"\n");
                             });
        
    }
    
    public static Persona searchPersonByPhone(String telefono) throws Exception{
    //public static Persona searchPersonByPhone(String telefono) throws RuntimeException{
        
        if (agenda.containsKey(telefono)) return agenda.get(telefono);
        else {
            //return null; //si devuelvo nulo, desde donde llamo al método debe controlar if != null
            throw new Exception("No existe en la agenda una persona con el teléfono "+telefono); //propaga una excepción que debes chequear con try catch y volvera a propagar
            //throw new RuntimeException("No existe en la agenda una persona con el teléfono "+telefono);
        }
    }
    
    public static String searchPhoneByPerson(Persona persona){
        if (agenda.containsValue(persona)){
            for (String k: agenda.keySet()){
                if (agenda.get(k).equals(persona))
                    return k;
            }
        }
        //else return null;
        else throw new RuntimeException("No existe en la agenda de teléfonos la persona con DNI " + persona.getDni());
        
        return null;
    }
    
    // Método para modificar el teléfono de una pesona en concreto.
    public static void updatePhone(Persona persona,String telefonoNuevo){
        String phone = searchPhoneByPerson(persona);
        if (phone != null){
            //Ha encontrado el teléfono de la persona
            agenda.remove(phone);
            agenda.put(telefonoNuevo,persona);
        }
        
    }
    
    public static Persona addPerson(Persona persona, String telefono) {
        //Se puede insertar un valor sí o solo sí la clave no está insertada,
        //y si lo está, nos devuelve el valor antiguo. En otro caso devuelve nulo
        return agenda.putIfAbsent(telefono, persona);
    }    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
        // Se puede insertar un valor sí o solo sí la clave no está insertada,
        // y si lo está, nos devuelve el valor antiguo. En otro caso devuelve nulo
        Producto monitor = hashMap.putIfAbsent("MON274K034", new Producto("MON274K034", "Monitor 27 4K", 450.0f));

        // Se puede comprobar si se contiene alguna clave, o algún valor.
        if (hashMap.containsKey("PC000123"))
            System.out.println("El Map contiene la clave");

        if (hashMap.containsValue(pc))
            System.out.println("El Map contiene el valor");

        // También podemos hacer uso de getOrDefault
        // si queremos obtener el valor asociado
        // a una referencia y, si no existe, un valor por defecto
        System.out.println(hashMap.getOrDefault("MON274K034", monitor));
    */
    
    /* 
     //Estilo clásicoc
        if (agenda.constainsKey("telefono"))
            System.out.println("Está repe...");
        else
            agenda.put("telefono",persona);
    
    
            //Para modificar... containskey, luego agenda.put(telef,persona);
    */

}
