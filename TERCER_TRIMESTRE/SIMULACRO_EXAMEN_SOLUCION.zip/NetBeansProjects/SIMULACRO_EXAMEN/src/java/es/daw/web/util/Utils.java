package es.daw.web.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 *
 * @author daw1a
 */
public class Utils {
    
    public static List<String> leerCSV(String path_csv) throws IOException{
        Path csv = Paths.get(path_csv);
        List<String> lineas = Files.readAllLines(csv);
        return lineas;
    }
}
