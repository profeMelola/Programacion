package es.daw.web.bd;

import es.daw.web.model.Fabricante;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author daw1a
 */
public class DaoFabricante implements Dao<Fabricante>{

    /****************************************************************/
    private Connection con = null;

    private static DaoFabricante instance = null;
    
    private DaoFabricante() throws SQLException {
        con = DBConnection.getConnection();
    }
    
    public static DaoFabricante getInstance() throws SQLException {
        if (instance == null) {
            instance = new DaoFabricante();
        }

        return instance;
    }
    
    public void close() throws SQLException {
        DBConnection.closeConnection();
    }
    /***************************************************************/
    
    
    
    @Override
    public Fabricante select(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Fabricante> selectAll() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void insert(Fabricante t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Fabricante t) throws SQLException {
        try(PreparedStatement ps = con.prepareStatement("UPDATE tienda.fabricante "
                + "SET nombre = ? where codigo = ?")){
            ps.setString(1,t.getNombre());
            ps.setInt(2,t.getCodigo());
            ps.executeUpdate();
            
        }
    }

    @Override
    public void delete(Fabricante t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
