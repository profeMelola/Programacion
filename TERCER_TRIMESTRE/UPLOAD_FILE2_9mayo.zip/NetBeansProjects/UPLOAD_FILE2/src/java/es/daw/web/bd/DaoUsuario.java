package es.daw.web.bd;

import es.daw.web.model.Usuario;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * CRUD:
 * "Crear, Leer, Actualizar y Borrar" (del original en inglés: Create, Read, Update and Delete)
 * Se usa para referirse a las funciones básicas en bases de datos 
 * o la capa de persistencia en un software.
 * 
 * EJEMPLO DE IMPLEMENTACIÓN DEL PATRÓN DAO (DataAccess Object) CON LA TABLA PERSONAS
 * 
 * DAO abstrae del SGBC. Usado para el acceso a datos (independientemente de la fuente de los datos)
 * 
 * OFRECEMOS LOS MÉTODOS
 *
 * - select
 * - selectAll
 * - update
 * - delete
 *
 * TAMBIÉN IMPLEMENTAMOS EL PATRÓN SINGLETON
 *
 * @author daw1a
 */
public class DaoUsuario implements Dao<Usuario>{
    
    /***************************************************************************
     * Propiedades y métodos SINGLETON
     * 
     * Nos interesa tener solo una instancia que a su vez tiene una única 
     * instancia de la conexión
     */
    private Connection con = null;

    private static DaoUsuario instance = null;
    
    private DaoUsuario() throws SQLException {
        con = DBConnection.getConnection();
    }
    
    public static DaoUsuario getInstance() throws SQLException {
        if (instance == null) {
            instance = new DaoUsuario();
        }

        return instance;
    }
    
    public void close() throws SQLException {
        DBConnection.closeConnection();
    }

    @Override
    public Usuario select(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Usuario> selectAll() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void insert(Usuario t) throws SQLException {
        
        // -------------
        
        try(PreparedStatement ps = con.prepareStatement("INSERT INTO fotos.usuario "
                + "(nombre, email, fecha, foto) "
                + "VALUES (?, ?, ?, ?)")){
            
            ps.setString(1, t.getNombre());
            ps.setString(2, t.getEmail());
            ps.setDate(3, Date.valueOf(t.getFecha()));
            
            
            Path foto_path = Paths.get(t.getPath_foto());
            InputStream fotoStream = null;
            try {
                fotoStream = Files.newInputStream(foto_path);
                ps.setBlob(4, fotoStream);
            }catch(IOException e){
                System.err.println("[INSERT] error al crear el usuario");
                e.printStackTrace();
            }finally{
                if (fotoStream != null){
                    try{
                        fotoStream.close();
                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
            }
            
            ps.executeUpdate();
        }
        
        
    }

    @Override
    public void update(Usuario t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(Usuario t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    /**************************************************************************
     * Propiedades y método de la clase DAO
     */
    
    
}
