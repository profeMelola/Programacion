package es.daw.poo.dao;

import es.daw.poo.model.AguaMineral;
import es.daw.poo.model.Bebida;
import es.daw.poo.model.BebidaAzucarada;
import java.util.ArrayList;

/**
 *
 * @author melol
 */
public class BebidaDAO {
private ArrayList<Bebida> bebidas = new ArrayList<>();
    
    public BebidaDAO(){
        bebidas.add(new AguaMineral("manantial1", 1.5, 5, "Bezoya"));
        bebidas.add(new BebidaAzucarada(0.2, true, 1.5, 10, "Coca Cola"));
        bebidas.add(new BebidaAzucarada(0.1, true, 2, 9, "Fanta"));
        bebidas.add(new AguaMineral("manantial2", 2, 8, "Solán de Cabras"));
        bebidas.add(new BebidaAzucarada(0.3, false, 2, 15, "Trina"));
        bebidas.add(new AguaMineral("manantial3", 2, 6, "Liviana"));
    }
    
    public ArrayList<Bebida> select() {
        return (ArrayList<Bebida>) bebidas.clone();
    }                
}
