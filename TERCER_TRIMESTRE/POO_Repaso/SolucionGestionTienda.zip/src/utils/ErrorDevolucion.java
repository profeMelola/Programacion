/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author idesadadaw
 */
public class ErrorDevolucion extends Exception {

    private String codigo;
    private String mensaje;

    public ErrorDevolucion(String codigo) {
        this.codigo = codigo;
       
    }

    public String getMensaje() {
        switch (codigo) {
            case "01":
                mensaje = "EJEMPLAR YA ALQUILADO";
                break;
            case "02":
                mensaje = "CLIENTE NO ALQUILÓ EL EJEMPLAR";
                break;
            case "03":
                mensaje = "EL EJEMPLAR NO ESTÁ ALQUILADO";
                break;
            default:
                mensaje = "ERROR NO DEFINIDO";
        }
        return mensaje;
    }

}
