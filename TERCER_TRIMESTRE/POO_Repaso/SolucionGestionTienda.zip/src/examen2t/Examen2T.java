package examen2t;

import DAO_ejemplares.DAOejemplares;
import clases.Ejemplar;
import utils.ErrorDevolucion;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author idesadadaw
 */
public class Examen2T {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ArrayList<Ejemplar> lista;
        lista = DAOejemplares.getCatalogo();
        Collections.sort(lista);
        mostrarEjemplares(lista);
        alquilar(buscaEjemplar("El Quijote", lista), LocalDate.of(2022, 02, 11), 0);
        alquilar(buscaEjemplar("El Quijote II", lista), LocalDate.of(2022, 02, 11), 0);
        alquilar(buscaEjemplar("El Quijote II", lista), LocalDate.of(2022, 02, 11), 0);

        alquilar(buscaEjemplar("Odisea", lista), LocalDate.of(2022, 03, 11), 0);
        alquilar(buscaEjemplar("Odisea", lista), LocalDate.of(2022, 03, 11), 0);
        alquilar(buscaEjemplar("Odisea II", lista), LocalDate.of(2022, 03, 11), 0);
        mostrarEjemplaresNoAlquilados(lista);
        mostrarEjemplaresAlquilados(lista);

        devolver(buscaEjemplar("El Quijote", lista), LocalDate.of(2022, 02, 12), 0);
        devolver(buscaEjemplar("El Quijote II", lista), LocalDate.of(2022, 03, 12), 0);
        devolver(buscaEjemplar("Odisea", lista), LocalDate.of(2022, 03, 12), 1);
        devolver(buscaEjemplar("Odisea", lista), LocalDate.of(2022, 03, 12), 0);
        devolver(buscaEjemplar("Odisea II", lista), LocalDate.of(2022, 03, 15), 0);
        devolver(buscaEjemplar("Marianela", lista), LocalDate.of(2022, 03, 15), 0);
        alquilar(buscaEjemplar("Odisea II", lista), LocalDate.of(2022, 03, 16), 0);
        devolver(buscaEjemplar("Odisea II", lista), LocalDate.of(2022, 03, 17), 0);
    }

    public static Ejemplar buscaEjemplar(String titulo, ArrayList<Ejemplar> lista) {
        for (Ejemplar e : lista) {
            if (e.getTitulo().equals(titulo)) {
                return e;
            }
        }

        return null;
    }

    public static void alquilar(Ejemplar ejemplar, LocalDate fecha, int idCliente) {
        try {
            ejemplar.alquilar(fecha, idCliente);
        } catch (ErrorDevolucion e) {
            System.out.println(e.getMensaje());
        }

    }

    public static void devolver(Ejemplar ejemplar, LocalDate fecha, int idCliente) {

        try {
            System.out.println("Precio:  " + ejemplar.getTitulo() + " " + ejemplar.devolver(fecha, idCliente));
        } catch (ErrorDevolucion ex) {
            System.out.println(ex.getMensaje());
        }

    }

    public static void mostrarEjemplares(ArrayList<Ejemplar> lista) {
        System.out.println("MUESTRA LOS EJEMPLARES ");

        // recorrer el arrayList y mostrar 
        for (Ejemplar e : lista) {

            System.out.println(e);

        }
    }

    public static void mostrarEjemplaresNoAlquilados(ArrayList<Ejemplar> lista) {
        System.out.println("MUESTRA LOS EJEMPLARES  NO ALQUILADOS");

        // recorrer el arrayList y mostrar 
        for (Ejemplar e : lista) {
            if (!e.isAlquilado()) {
                System.out.println(e);
            }
        }

    }

    public static void mostrarEjemplaresAlquilados(ArrayList<Ejemplar> lista) {
        System.out.println("MUESTRA LOS EJEMPLARES   ALQUILADOS");

        // recorrer el arrayList y mostrar 
        for (Ejemplar e : lista) {
            if (e.isAlquilado()) {
                System.out.println(e);
            }

        }

    }

}
