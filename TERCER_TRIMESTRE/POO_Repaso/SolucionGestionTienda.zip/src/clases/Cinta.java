/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import utils.ErrorDevolucion;
import java.time.LocalDate;



/**
 *
 * @author idesadadaw
 */
public class Cinta extends Ejemplar {

    private int tipoIva = 10;
    private double precioFijo;
    private double multa = 10;

    public Cinta(String titulo,  double precioFijo) {
        super(titulo);
        super.setTipoIva(tipoIva);
        this.precioFijo = precioFijo;
    }

    @Override
    public double devolver(LocalDate fechaDevolucion, int idCliente) throws ErrorDevolucion {

        long dias;
        double iva = 0;
        if (!isAlquilado()) {
            throw new ErrorDevolucion("01");
        }
        dias = calculaDias(getFechaAlquiler(), fechaDevolucion);
        if (getIdCliente() != idCliente) {

            throw new ErrorDevolucion("02");

        }
        if (dias > 3) {
            precioFijo += multa;
        }
        setFechaAlquiler(null);
        setAlquilado(false);
        setIdCliente(0);
        iva = precioFijo * tipoIva / 100;
        return precioFijo;// + iva;

    }

    @Override
    public String toString() {
        return "Cinta{" + super.toString() + "tipo IVA=" + tipoIva + "%, precio fijo=" + precioFijo + '}';
    }

  
}
