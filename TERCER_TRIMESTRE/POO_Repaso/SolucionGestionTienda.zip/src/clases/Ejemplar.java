/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import utils.ErrorDevolucion;
import java.time.LocalDate;
import static java.time.temporal.ChronoUnit.DAYS;

/**
 *
 * @author idesadadaw
 */
public abstract class Ejemplar implements Comparable<Ejemplar> {

    private final String titulo;

    private double tipoIva;

    private int idEjemplar;
    private LocalDate fechaAlquiler;
    private boolean alquilado;
    private static int contador;
    private int idCliente;

    public Ejemplar(String titulo) {
        this.titulo = titulo;

        this.alquilado = false;
        this.idEjemplar = contador;
        contador++;
    }

    public double getTipoIva() {
        return tipoIva;
    }

    public void setTipoIva(double tipoIva) {
        this.tipoIva = tipoIva;
    }

    public String getTitulo() {
        return titulo;
    }

    public void alquilar(LocalDate fechaAlquiler, int idCliente) throws ErrorDevolucion {

        if (!alquilado) {
            this.alquilado = true;
            this.fechaAlquiler = fechaAlquiler;
            this.idCliente = idCliente;
        } else {
            throw new ErrorDevolucion("01");
        }

    }

    public abstract double devolver(LocalDate fechaDevolucion, int idCliente) throws ErrorDevolucion;

    public boolean isAlquilado() {
        return alquilado;
    }

    public void setAlquilado(boolean alquilado) {
        this.alquilado = alquilado;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public void setFechaAlquiler(LocalDate fechaAlquiler) {
        this.fechaAlquiler = fechaAlquiler;
    }

    public LocalDate getFechaAlquiler() {
        return fechaAlquiler;
    }

    public int getIdEjemplar() {
        return idEjemplar;
    }

    @Override
    public String toString() {
        return "titulo=" + titulo + ", id: " + idEjemplar + ", fecha de Alquiler: " + fechaAlquiler + " ";
    }

    public long calculaDias(LocalDate alquiler, LocalDate devolucion) {
        long dias = DAYS.between(getFechaAlquiler(), devolucion);
        return dias;
    }

    @Override
    public int compareTo(Ejemplar arg0) {

        return this.titulo.compareTo(arg0.titulo);
    }

}
