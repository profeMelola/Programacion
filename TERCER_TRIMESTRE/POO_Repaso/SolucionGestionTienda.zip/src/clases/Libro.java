/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import utils.ErrorDevolucion;
import java.time.LocalDate;


/**
 *
 * @author idesadadaw
 */
public class Libro extends Ejemplar {

    private int tipoIva = 4;
    private double precioFijo;

    public Libro(String titulo,  double precioFijo) {
        super(titulo);
        super.setTipoIva(tipoIva);
        this.precioFijo = precioFijo;

    }

    @Override
    public double devolver(LocalDate fechaDevolucion, int idCliente) throws ErrorDevolucion {
        double precio;
       
        if(!isAlquilado())
            throw new ErrorDevolucion("03");
        if (getIdCliente() != idCliente) {
            throw new ErrorDevolucion("02");

        }
        /*liberamos la id del cliente*/
        precio = calcularPrecio(fechaDevolucion);
        setFechaAlquiler(null);
        setIdCliente(0);
        setAlquilado(false);
        return precio;

    }

    private double calcularPrecio(LocalDate fechaDevolucion) {

        long dias = calculaDias(getFechaAlquiler(), fechaDevolucion);
      
        double iva = (dias * precioFijo) * tipoIva / 100;
        return dias * precioFijo + iva;
    }

    @Override
    public String toString() {
        return "Libro{" + super.toString() + "tipoIva=" + tipoIva + ", precioFijo=" + precioFijo + '}';
    }

}
