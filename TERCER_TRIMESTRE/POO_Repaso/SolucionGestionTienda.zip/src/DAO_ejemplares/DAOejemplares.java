/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO_ejemplares;

import clases.Cinta;
import clases.Ejemplar;
import clases.Libro;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author idesadadaw
 */
public class DAOejemplares {

    // public Cinta(String titulo, double precioCompra, LocalDate fechaCompra, double precioFijo)
    public static ArrayList<Ejemplar> getCatalogo() {
        ArrayList<Ejemplar> lista = new ArrayList();
        lista.add(new Libro("El Quijote",   0.15));
        lista.add(new Cinta("Odisea",   4));
        lista.add(new Libro("El Quijote II",   0.15));
        lista.add(new Libro("Marianela",   0.15));
        lista.add(new Cinta("Odisea II",   4));

        return lista; 
    }
}
