package es.daw.poo;

import es.daw.poo.dao.BebidaDAO;
import es.daw.poo.model.AguaMineral;
import es.daw.poo.model.Almacen;
import es.daw.poo.model.Bebida;
import es.daw.poo.model.BebidaAzucarada;
import java.util.ArrayList;

/**
 *
 * @author melol
 */
public class App_Almacen {

    public static void main(String[] args) {

        //Creo el almacen
        // Si en el constructor no se crea nada, se crea de 3 por 3
        Almacen a = new Almacen();

        //------------------------------------------------------------
        // Cargar en un ArrayList de Bebida los datos obtenidos del DAO
        ArrayList<Bebida> bebidas = new ArrayList<>();
		
        BebidaDAO DAO = new BebidaDAO();
		
		// Pendiente de completar.....

        //------------------------------------------------------------
		
		//Agregar bebidas al almacen
		//Pista: rrecorre el arraylist para ello y usa a.agregarBebida....
		

        //Muestro las bebidas
        a.mostrarBebidas();

        //Calculo el precio de todas las bebidas
        System.out.println("Precio de todas las bebidas " + a.calcularPrecioBebidas());

        //Elimino una bebida en concreto
        a.eliminarBebida(4);

        //Muestro las bebidas
        a.mostrarBebidas();

        //
        System.out.println("Precio de todas las bebidas" + a.calcularPrecioBebidas());

        System.out.println("Precio de todas las bebidas de la marca bezoya" + a.calcularPrecioBebidas("bezoya"));

        System.out.println("Calcular el precio de la columna 0 (se corresponde con una estantería): " + a.calcularPrecioBebidas(0));

    }
}
