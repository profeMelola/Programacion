package es.daw.poo.model;

public class Almacen {
 
    //Atributos
    private Bebida[][] estanteria;
 
    //Constructores
    public Almacen(int filas, int columnas) {
        estanteria = new Bebida[filas][columnas];
    }
 
    public Almacen() {
        estanteria = new Bebida[3][3];
    }
 
    //Metodos
     
    /**
     * Agega una bebida, primera posicion que encuentre
     * @param b 
     */
    public void agregarBebida(Bebida b) {
 
    }
 
    /**
     * Elimina la bebida con el id que le pasen, sino esta se indica
     * @param id 
     */
    public void eliminarBebida(int id) {
 
    }
 
    /**
     * Recorro las estantenrias y muestro las bebidas
     */
    public void mostrarBebidas() {
 
    }
 
    /**
     * Calculo el precio de todas las bebidas
     * @return 
     */
    public double calcularPrecioBebidas() {
    }
 
    /**
     * Calculo el precio de todas las bebidas dde una marca
     * @param marca
     * @return 
     */
    public double calcularPrecioBebidas(String marca) {
    }
 
    /**
     * Calculo el precio de todas las bebidas de una determinada columna
     * @param columna
     * @return 
     */
    public double calcularPrecioBebidas(int columna) {
		
    }
 
}
