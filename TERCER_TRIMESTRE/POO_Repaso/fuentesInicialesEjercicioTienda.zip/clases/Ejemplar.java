package clases;

import java.time.LocalDate;
import static java.time.temporal.ChronoUnit.DAYS;

/**
 *
 * @author examen_segundaEvaluacion
 */
public abstract class Ejemplar {

    private final String titulo;
    private double tipoIva;
    private int idEjemplar;
    private LocalDate fechaAlquiler;
    private boolean alquilado;
    private int idCliente;

    public Ejemplar(String titulo) {
        this.titulo = titulo;
       /** COMPLETA AQUÍ EL CÓDIGO NECESARIO EN EL CONSTRUCTOR*/

  
    }

    public double getTipoIva() {
        return tipoIva;
    }

    public void setTipoIva(double tipoIva) {
        this.tipoIva = tipoIva;
    }

    public String getTitulo() {
        return titulo;
    }

    public boolean isAlquilado() {
        return alquilado;
    }

    public void setAlquilado(boolean alquilado) {
        this.alquilado = alquilado;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public void setFechaAlquiler(LocalDate fechaAlquiler) {
        this.fechaAlquiler = fechaAlquiler;
    }

    public LocalDate getFechaAlquiler() {
        return fechaAlquiler;
    }

    public int getIdEjemplar() {
        return idEjemplar;
    }

   public long calculaDias(LocalDate alquiler, LocalDate devolucion){
        long dias = DAYS.between(getFechaAlquiler(), devolucion);
        return dias;
   }
}
