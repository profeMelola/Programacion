/**
 * Practicando con FileInputStream
 * Flujo de entrada de bytes
 * Flujo que permite leer de un fichero byte a byte
 */
package bytes.fileinput;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class EjemploFileInputStream {

    /**
     * @param args
     */
    public static void main(String[] args) {

        FileInputStream fIn = null;

        try {
            fIn = new FileInputStream("primero.dat");
            int c;
            while ((c = fIn.read()) != -1) { //hasta que lleguemos a final del fichero
                System.out.println(c);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fIn != null){
                try {
                    fIn.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

}
