package ficheros;

import java.io.*;

public class CreaDir {

    public static void main(String[] args) {

        File d;

        d = new File("NUEVODIR");
        File f1 = new File(d, "FICHERO1.TXT");
        File f2 = new File(d, "FICHERO2.TXT");
        File z = null;
        if (d.mkdir()) {
            System.out.println("SE HA CREADO EL"); //directorio que creo a partir del actual
        } else {
            System.out.println("NOR SE HA CREADO EL");
        }
        //CREAR DIRECTORIO

        try {
            /*   if (f1.createNewFile())
       System.out.println("FICHERO1 creado correctamente...");
    else
       System.out.println("No se ha podido crear FICHERO1...");*/

            if (f2.createNewFile()) {
                System.out.println("FICHERO2 creado correctamente...");
            } else {
                System.out.println("No se ha podido crear FICHERO2...");
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        if (f1.renameTo(new File(d, "FICHERO1NUEVO")));//renombro FICHERO1
        System.out.println("no se puede renombrar");;//renombro FICHERO1
        //f2.renameTo(z);//renombro FICHERO1;

        try {
            File f3 = new File("NUEVODIR/FICHERO3.TXT");
            f3.createNewFile();//crea FICHERO3 en NUEVODIR
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
