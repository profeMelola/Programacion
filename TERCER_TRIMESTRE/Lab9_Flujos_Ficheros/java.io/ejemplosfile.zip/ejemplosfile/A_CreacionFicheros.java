/**
 * Creación de ficheros y ficheros temporales
 */
package ejemplosfile;

import java.io.File;
import java.io.IOException;

/**
 * Es bueno conocerla porque os podéis encontrar con proyectos que lo utilicen...
 * Es versátil pero ha quedado obsoleta....
 * La tendencia, usar java.nio
 * @author melol
 */
public class A_CreacionFicheros {

    /**
     * @param args
     */
    public static void main(String[] args) {

        try {
            //File f = new File("./prueba/", "nuevo.txt"); //esto da error porque el directorio debe existir
            File f = new File("nuevo2.txt");
            f.createNewFile();

            File temp = File.createTempFile("temporal", ".tmp"); //los borra el S.O según tenga planificado
            System.out.println(temp.getAbsolutePath());
            
            System.out.println("* getName: "+f.getName());
            System.out.println("* getAbsolutePath: "+f.getAbsolutePath());
            System.out.println("* getCanonicalPath: "+f.getCanonicalPath()); //no usa . ni ..
            
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
