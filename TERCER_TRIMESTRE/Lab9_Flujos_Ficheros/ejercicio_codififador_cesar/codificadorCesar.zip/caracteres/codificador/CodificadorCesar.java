/**
 * LA CODIFICACIÓN CÉSAR ES AQUELLA QUE TRANSFORMA UN MENSAJE, CAMBIANDO CADA LETRA
 * POR AQUELLA QUE OCUPA 3 POSICIONES DESPUÉS EN EL ABECEDARIO.
 * ESTE PROGRAMA IMPLEMENTA DICHA CODIFICACIÓN, TRANSFORMANDO UN FICHERO DE TEXTO.
 * ES UN ALGORITMO DE ENCRIPTACIÓN SIMÉTRICO
 */
package caracteres.codificador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CodificadorCesar {

    /**
     * @param args
     */
    public static void main(String[] args) {

        final int OFFSET = 3; //desplazamiento

        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            br = new BufferedReader(new FileReader("mensaje.txt"));
            bw = new BufferedWriter(new FileWriter("mensaje_cifrado.txt"));

            String linea = null;

            while ((linea = br.readLine()) != null) { //devuelve la cadena de caracteres (línea) 
                                                        //y cuando no quedan más datos devuelve null
                StringBuilder sb = new StringBuilder(linea.length());
                //Recorremos la línea en mayúsuclas carácter a carácter
                for (char c : linea.toUpperCase().toCharArray()) {
                    char result;
                    if (Character.isLetter(c)) {
                        int intValue = (int) c - 'A'; //cogemos como referencia el valor entero de la letra A 
                                                        //y restamos nuestro carácter sobre la A
                                                     // A - A = 0; B - A = 1
                        int intResult = (intValue + OFFSET) % 26; //últimas tres letras del abecedario tienen que ser correspondidas con la A, B y C consecutivamente
                                                                    // Si intValue+offset fuera 27, el módulo 26 sería 1 y le correspondería ..
                                                                    // ej: la Y es 89 - 65 (A) = 24 + 3 = 27 % 26 = 1
                                                                    // ej: la X es 88 - 65 = 23 + 3 = 26 % 26 = 0
                                                                    // ej: la Z es 90 - 65 = 25 + 3 = 28 % 26 = 2
                        result = (char) ('A' + intResult);
                    } else {
                        //si no es una letra lo dejamos como está
                        result = c;
                    }
                    sb.append(result);
                }
                bw.write(sb.toString());
                bw.newLine();

            }
            System.out.println("El mensaje ha sido cifrado correctamente");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

}
