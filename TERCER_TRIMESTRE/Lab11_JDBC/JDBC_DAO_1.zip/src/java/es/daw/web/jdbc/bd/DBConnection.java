package es.daw.web.jdbc.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * PATRÓN SINGLETON Este patrón de diseño se encarga de que una clase
 * determinada unicamente pueda tener un único objeto. El patrón Singleton, o
 * patrón de instancia única, es un patrón de diseño encargado de restringir la
 * creación de objetos de una clase (o el valor de un tipo) a un único objeto.
 * Genera una única instancia en la ejecución del programa y proporciona un
 * acceso global a la misma.
 *
 * DBConnection: esta es la clase que me va a permitir conectar a la B.D
 *
 * @author daw1a
 */
public class DBConnection {

    private static final String JDBC_URL = "jdbc:mysql://localhost/tienda";

    private static Connection con = null;

    private DBConnection() {
    } //De esta forma nadie puede hacer un new de DBConnection con constructor vacío por defecto

    /**
     * Método para obtener la conexión
     * @return
     * @throws SQLException 
     */
    public static Connection getConnection() throws SQLException {

        // La primera vez se carga la conexión, las siguientes veces se reutiliza la conexión
        // La primera vez tarda más
        if (con == null) {
            Properties props = new Properties();
            props.put("user", "root");
            props.put("password", "mysql");
            con = DriverManager.getConnection(JDBC_URL, props);
        }

        return con;
    }

    /**
     * Método para cerrar la conexión
     * @throws SQLException 
     */
    public static void closeConnection() throws SQLException {
        if (con != null) {
            con.close();
        }
    }
}
