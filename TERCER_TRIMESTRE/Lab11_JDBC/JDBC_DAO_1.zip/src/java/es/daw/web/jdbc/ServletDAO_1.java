package es.daw.web.jdbc;

import es.daw.web.jdbc.bd.DaoProducto;
import es.daw.web.jdbc.model.Fabricante;
import es.daw.web.jdbc.model.Producto;
import es.daw.web.jdbc.util.Utils;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author daw1a
 */
@WebServlet(urlPatterns = {"/ServletDAO_1"})
public class ServletDAO_1 extends HttpServlet {

    // Mirar a ver qué necesito como variables globales al Servlet
    private String appPath = "";
    
    private DaoProducto daoP = null;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener el path /opt/wildfly/standalone/deployments/JDBC_tablas_con_log.war
        if (appPath.equals("")) {
            appPath = request.getServletContext().getRealPath("");
        }

        List<Producto> productos = null;
        List<Fabricante> fabricantes = null;

        
        try {
            daoP = DaoProducto.getInstance();
            productos = daoP.selectAll();
            System.out.println("[processRequest] Se han cargado los datos de los productos en la colección");

        } catch (SQLException e) {
            System.err.println("[processRequest][ERROR REALIZAR CONSULTA]" + e.getMessage());
        }

        //DaoFabricante daoF = null;
        // 4. Devolver salida html
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet- Práctica tercer trimestre</title>");
            out.println("</head>");
            out.println("<body>");

            out.println("<h1>TABLA DE PRODUCTOS</h1>");
            out.println("<table border='1'>");

            out.println("<tr><th>CÓDIGO</th><th>NOMBRE</th><th>PRECIO</th><th>COD PROD</th></tr>");
            if (productos != null) {
                for (Producto p : productos) {
                    out.println("<tr>");
                    out.println("<td>" + p.getCodigo() + "</td>");
                    out.println("<td>" + p.getNombre() + "</td>");
                    out.println("<td>" + p.getPrecio() + "</td>");

                    out.println("<td>" + p.getCodigo_fabricante() + "</td>");

                    // En vez del código que salga el nombre del fabricante
                    //out.println("<td>" + Utils.getNombreFabricante(p.getCodigo_fabricante(),fabricantes) + "</td>");
                    out.println("</tr>");
                }
            }

            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    
    @Override
    public void destroy() {
        super.destroy();
        
        try {
            daoP.close();
        } catch (SQLException ex) {
            System.err.println("[processRequest][ERROR AL CERRA LA CONEXIÓN]" + ex.getMessage());
        }
        
    }    
}
