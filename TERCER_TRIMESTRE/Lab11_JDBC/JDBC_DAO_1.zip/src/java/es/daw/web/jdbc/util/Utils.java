package es.daw.web.jdbc.util;

import es.daw.web.jdbc.model.Fabricante;
import es.daw.web.jdbc.model.Producto;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author daw1a
 */
public class Utils {
    
    public static String getNombreFabricante(int cod_fab,ArrayList<Fabricante> fabricantes){
        //Encontrar a través del código
        
        Optional<Fabricante> f_opt = fabricantes
                .stream()
                .filter(f -> f.getCodigo() == cod_fab)
                .findFirst();
        if (f_opt.isPresent()) 
            return f_opt.get().getNombre();
        else 
            return "";
        
        //return fabricantes.stream().filter(f -> f.getCodigo() == cod_fab).findFirst().get().getNombre();
                
    }
    
    public static String getNombreFabricante2(int cod_fab,ArrayList<Fabricante> fabricantes){
        //Encontrar a través del código
        Fabricante f_aux = new Fabricante();
        f_aux.setCodigo(cod_fab);
        int pos = fabricantes.indexOf(f_aux);
        
        if (pos != -1)
            return fabricantes.get(pos).getNombre();
        else
            return "";
                
                
    }
    
}
