package es.daw.web;

import es.daw.web.bd.DBConnection;
import es.daw.web.bd.DaoEmpleado;
import es.daw.web.model.Empleado;
import es.daw.web.util.Utils;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author daw1a
 */
@WebServlet(name = "CsvServlet", urlPatterns = {"/CsvServlet"})
public class CsvServlet extends HttpServlet {

    DaoEmpleado daoE = null;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        StringBuilder sb = new StringBuilder();
        boolean error = false;
        
        try {
            // --------------------------
            String applicationPath = request.getServletContext().getRealPath("");
            String uploadFilePath = applicationPath + File.separator + "LOG";
            Utils.writeLog(uploadFilePath, "["+Utils.getDateTime()+"] Realizando la operación de carga masiva CSV");
            //-----------------------------
            
            List<String> registros = Utils.leerCSV("empleados.csv");
            registros.forEach(System.out::println);
            
            daoE = DaoEmpleado.getInstance();
            
            
            //nif,nombre,apellido1,apellido2,codigo_departamento
            /*
            registros.forEach(registro -> {
                int contador = 0;
                
                if (contador > 0) {
                    String[] campos = registro.split(",");
                    Empleado e = new Empleado();
                    e.setNIF(campos[0]);
                    e.setNombre(campos[1]);
                    e.setApellido1(campos[2]);
                    e.setApellido2(campos[3]);
                    e.setCodigo_departamento(Integer.parseInt(campos[4]));
                    try {
                        daoE.insert(e);
                    } catch (SQLException ex) {
                        Logger.getLogger(CsvServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else contador++;
            });*/
            int contador = 0;
            for(String registro: registros){
                if (contador > 0) {
                    
                    String[] campos = registro.split(",");
                    
                    Empleado e = new Empleado();
                    
                    //Debo comprobar que el NIF tenga un formato correcto
                    if (Utils.checkExpresionRegular("[0-9]{8}[A-Z]{1}",campos[0])){
                        e.setNIF(campos[0]);
                        e.setNombre(campos[1]);
                        e.setApellido1(campos[2]);
                        e.setApellido2(campos[3]);
                        e.setCodigo_departamento(Integer.parseInt(campos[4]));
                        daoE.insert(e);
                    }else{
                        error = true;
                        sb.append("<p>El NIF "+campos[0]+" no tiene un formato correcto</p>");
                    }
                    
                } else contador++;
                
            }

        } catch (SQLException ex) {
            //error = true;
            Logger.getLogger(CsvServlet.class.getName()).log(Level.SEVERE, null, ex);
            request.setAttribute("message", ex.getMessage());
            getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
        }

        // -------------------------------
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CsvServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Carga masiva de empleados:</h1>");
            if (!error)
                out.println("<p>Se ha realizado correctamente la carga masiva de empleados a través del CSV</p>");
            else
                out.println(sb.toString());
            out.println("</body>");
            out.println("</html>");
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    @Override
    public void destroy() {
        super.destroy();
        
        try {
            DBConnection.closeConnection();
            //daoE.close();
            //daoD.close();
        } catch (SQLException ex) {
            System.err.println("[processRequest][ERROR AL CERRA LA CONEXIÓN]" + ex.getMessage());
        }
        
    }   
}
