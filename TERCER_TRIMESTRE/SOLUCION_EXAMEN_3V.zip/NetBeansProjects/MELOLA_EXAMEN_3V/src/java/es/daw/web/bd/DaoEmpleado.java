package es.daw.web.bd;

import es.daw.web.model.Empleado;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author daw1a
 */
public class DaoEmpleado implements Dao<Empleado> {

    /**
     * ************************************************************************
     */
    private Connection con = null;

    private static DaoEmpleado instance = null;

    private DaoEmpleado() throws SQLException {
        con = DBConnection.getConnection();
    }

    public static DaoEmpleado getInstance() throws SQLException {
        if (instance == null) {
            instance = new DaoEmpleado();
        }

        return instance;
    }

    public void close() throws SQLException {
        DBConnection.closeConnection();
    }

    /**
     * ************************************************************************
     */
@Override
    public Empleado select(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Empleado> selectAll() throws SQLException {
        try ( PreparedStatement ps = con.prepareStatement("SELECT * FROM empleados.empleado")) {

            ResultSet rs = ps.executeQuery();

            List<Empleado> empleados = null;

            while (rs.next()) {
                if (empleados == null) {
                    empleados = new ArrayList<>();
                }

                Empleado e = new Empleado();
                e.setNombre(rs.getString("nombre"));
                e.setApellido1(rs.getString("apellido1"));
                e.setApellido2(rs.getString("apellido2"));
                e.setCodigo(rs.getInt("codigo"));
                e.setNIF(rs.getString("NIF"));
                e.setCodigo_departamento(rs.getInt("codigo_departamento"));
                empleados.add(e);
                System.out.println(e.toString());

            }

            return empleados;

        }
    }

    @Override
    public void insert(Empleado t) throws SQLException {
        //nif,nombre,apellido1,apellido2,codigo_departamento
        try ( PreparedStatement ps = con.prepareStatement("INSERT INTO empleados.empleado (nif, nombre, apellido1, apellido2, codigo_departamento) VALUES (?, ?, ?, ?, ?)")) {
            ps.setString(1, t.getNIF());
            ps.setString(2, t.getNombre());
            ps.setString(3, t.getApellido1());
            ps.setString(4, t.getApellido2());
            ps.setInt(5, t.getCodigo_departamento());

            ps.executeUpdate();

        }
    }

    @Override
    public void update(Empleado t) throws SQLException {
        try(PreparedStatement ps = con.prepareStatement("UPDATE empleados.empleado "
                + "SET codigo_departamento = ? where nif = ?")){
            ps.setInt(1,t.getCodigo_departamento());
            ps.setString(2,t.getNIF());

            ps.executeUpdate();
            
        }

    }

    @Override
    public void delete(Empleado t) throws SQLException {
        try(PreparedStatement ps = con.prepareStatement("DELETE FROM empleados.empleado "
                + "where nif = ?")){
            ps.setString(1,t.getNIF());

            ps.executeUpdate();
            
        }
    }

    @Override
    public void delete(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    

}
