
package es.daw.web.bd;

import es.daw.web.model.Departamento;
import es.daw.web.model.Empleado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author daw1a
 */
public class DaoDepartamento implements Dao<Departamento>{
    
    /***************************************************************************/
    private Connection con = null;

    private static DaoDepartamento instance = null;
    
    private DaoDepartamento() throws SQLException {
        con = DBConnection.getConnection();
    }
    
    public static DaoDepartamento getInstance() throws SQLException {
        if (instance == null) {
            instance = new DaoDepartamento();
        }

        return instance;
    }
    
    public void close() throws SQLException {
        DBConnection.closeConnection();
    }
    /***************************************************************************/
    

    @Override
    public Departamento select(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Departamento> selectAll() throws SQLException {
        try(PreparedStatement ps = con.prepareStatement("SELECT * FROM empleados.departamento")){
            
            ResultSet rs = ps.executeQuery();

            List<Departamento> departamentos = null;

            while (rs.next()) {
                if (departamentos == null) {
                    departamentos = new ArrayList<>();
                }

                Departamento d = new Departamento();
                d.setCodigo(rs.getInt("codigo"));
                d.setNombre(rs.getString("nombre"));
                d.setGastos(rs.getDouble("gastos"));
                d.setPresupesto(rs.getDouble("presupuesto"));
                departamentos.add(d);

            }

            return departamentos;

        }
        
        
    }

    @Override
    public void insert(Departamento t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Departamento t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(Departamento t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
