package es.daw.web;

import es.daw.web.bd.DBConnection;
import es.daw.web.bd.DaoDepartamento;
import es.daw.web.bd.DaoEmpleado;
import es.daw.web.model.Departamento;
import es.daw.web.model.Empleado;
import es.daw.web.util.Utils;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author daw1a
 */
@WebServlet(name = "MainServlet", urlPatterns = {"/MainServlet"})
public class MainServlet extends HttpServlet {

    DaoDepartamento daoD;
    DaoEmpleado daoE;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // --------------------------------------
        String nif = request.getParameter("nif");
        String departamento = request.getParameter("departamento");
        
        
        String accion = request.getParameter("accion");
        System.out.println("accion:"+accion);
        
        // ----------------------------------
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadFilePath = applicationPath + File.separator + "LOG";
        Utils.writeLog(uploadFilePath, "["+Utils.getDateTime()+"] Realizando la operación de "+accion);
        // -----------------------------------
        
        
        
        List<Empleado> empleados = null;
        List<Departamento> departamentos = null;
        
        try{
            daoD = DaoDepartamento.getInstance();
            daoE = DaoEmpleado.getInstance();
            
            switch (accion){
                case "listarTodos":
                    departamentos = daoD.selectAll();
                    daoE = DaoEmpleado.getInstance();
                    empleados = daoE.selectAll();
                    
                    break;
                    
                case "baja":
                    
                    if (empleados == null)
                        empleados = daoE.selectAll();
                    // Esto lo cargo de nuevo porque devuelvo el listado actualizado, pero en el examen no lo pido
                    if (departamentos == null)
                        departamentos = daoD.selectAll();
                    
                    if (nif != null){
                        if (nif.equals("")){
                            request.setAttribute("message", "Para realizar la operación debes especificar el NIF");
                            getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
                        }
                        else if (!Utils.existNIF(nif,empleados)){
                            request.setAttribute("message", "El NIF "+nif+" no existe en la base de datos");
                            getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
                        }
                        else{
                            Empleado e = new Empleado();
                            e.setNIF(nif);
                            daoE.delete(e);
                            //Siempre actualizo el listado de empleados para comprobar el DNI
                            empleados = daoE.selectAll();
                            System.out.println("********> Realizado el borrado");
                        }
                            
                    }else{
                        request.setAttribute("message", "Para realizar la operación debes especificar el NIF");
                        getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
                        
                    }                    

                    
                    break;
                    
                case "modificacion":
                    
                    if (empleados == null)
                        empleados = daoE.selectAll();
                        
                    // Esto lo cargo de nuevo porque devuelvo el listado actualizado, pero en el examen no lo pido
                    if (departamentos == null)
                        departamentos = daoD.selectAll();
                    
                    
                    if (nif != null){
                        if (nif.equals("")){
                            request.setAttribute("message", "Para realizar la operación debes especificar el NIF");
                            getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
                        }
                        else if (!Utils.existNIF2(nif,empleados)){
                            request.setAttribute("message", "El NIF "+nif+" no existe en la base de datos");
                            getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
                        }
                        else{
                            Empleado e = new Empleado();
                            e.setNIF(nif);
                            e.setCodigo_departamento(Integer.parseInt(departamento));
                            daoE.update(e);
                            //Siempre actualizo el listado de empleados para comprobar el DNI
                            empleados = daoE.selectAll();
                            System.out.println("********> Realizada la actualización");
                        }
                            
                    }else{
                        request.setAttribute("message", "Para realizar la operación debes especificar el NIF");
                        getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
                        
                    }                    
                    
                    break;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }

        
        // --------------------------------------
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>MainServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            
            out.println("<h1>Operación <"+accion+">realizada con éxito</h1>");
            
            out.println("<h2>TABLA DE EMPLEADOS</h2>");
            out.println("<table border='1'>");

            out.println("<tr><th>CÓDIGO</th><th>NIF</th><th>NOMBRE</th><th>APELLIDO 1</th><th>APELLIDO 2</th><th>DEPARTAMENTO</th></tr>");
            if (empleados != null) {

                empleados.sort( (e1,e2) -> e1.getApellido1().compareTo(e2.getApellido1()));

                for (Empleado e : empleados) {
                    out.println("<tr>");
                    out.println("<td>" + e.getCodigo() + "</td>");
                    out.println("<td>" + e.getNIF() + "</td>");
                    out.println("<td>" + e.getNombre() + "</td>");
                    out.println("<td>" + e.getApellido1() + "</td>");
                    out.println("<td>" + e.getApellido2() + "</td>");

                    //out.println("<td>" + e.getCodigo_departamento() + "</td>");

                    // En vez del código que salga el nombre del fabricante
                    //out.println("<td>" + Utils.getNombreDepartamento(e.getCodigo_departamento(),departamentos) + "</td>");
                    out.println("<td>" + Utils.getNombreDepartamento2(e.getCodigo_departamento(),departamentos) + "</td>");
                    out.println("</tr>");
                }
            }

            out.println("</table>");
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    @Override
    public void destroy() {
        super.destroy();
        
        try {
            DBConnection.closeConnection();
            //daoE.close();
            //daoD.close();
        } catch (SQLException ex) {
            System.err.println("[processRequest][ERROR AL CERRA LA CONEXIÓN]" + ex.getMessage());
        }
        
    }   
}
