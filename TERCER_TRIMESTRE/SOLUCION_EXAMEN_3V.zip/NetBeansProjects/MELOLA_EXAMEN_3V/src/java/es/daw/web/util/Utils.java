package es.daw.web.util;

import es.daw.web.model.Departamento;
import es.daw.web.model.Empleado;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author daw1a
 */
public class Utils {

    /**
     * Método que devuelve verdadero/falso dependiendo de si se cumple la
     * expresión regular
     *
     * @param expresionRegular String con la expresión regular
     * @param cadena String con la cadena de texto a validar
     * @return boolean
     */
    public static boolean checkExpresionRegular(String expresionRegular, String cadena) {
        Pattern pat = Pattern.compile(expresionRegular);
        Matcher mat = pat.matcher(cadena);
        return (mat.matches());

    }

    /**
     * Método que devuelve una cadena de texto con la fecha actual del sistema
     * en formato dd/MM/YYYY HH:mm:ss
     *
     * @return
     */
    public static String getDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY HH:mm:ss");
        String formatoFecha = sdf.format(new Date());
        return formatoFecha;
    }

    // -----------------------
    // MIS MÉTODOS AUXILIARES
    // -----------------------
    /**
     * Método para obtener el nombre del departamento
     * @param cod
     * @param departamentos
     * @return 
     */
    public static String getNombreDepartamento(int cod, List<Departamento> departamentos) {
        //Encontrar a través del código
        Optional<Departamento> f_opt = departamentos
                .stream()
                .filter(f -> f.getCodigo() == cod)
                .findFirst();
        if (f_opt.isPresent()) {
            return f_opt.get().getNombre();
        } else {
            return "";
        }

        //return fabricantes.stream().filter(f -> f.getCodigo() == cod_fab).findFirst().get().getNombre();
    }
    
    public static String getNombreDepartamento2(int cod, List<Departamento> departamentos) {
        String nombreDpto = "";
        for ( Departamento d: departamentos){
            if (d.getCodigo() == cod)
                //nombreDpto = d.getNombre();
                return d.getNombre();
        }
        
        return nombreDpto;
        
    }
    

    /**
     * Método que lee del fichero CSV y devuelve una colección List por cada línea
     * @param path_csv
     * @return
     * @throws IOException 
     */
    public static List<String> leerCSV(String path_csv) throws IOException {
        Path csv = Paths.get(path_csv);
        List<String> lineas = Files.readAllLines(csv);
        return lineas;
    }

    /**
     * Método que escribe en el fichero de log de la aplicación
     * @param uploadFilePath
     * @param mensaje
     * @throws IOException 
     */
    public static void writeLog(String uploadFilePath, String mensaje) throws IOException {
        Path p = Paths.get(uploadFilePath);
        if (!Files.exists(p)) {
            Files.createDirectory(p);
        }
        Path file = Paths.get(uploadFilePath, "examen3ev.log");
        
        Files.write(file, (mensaje+"\n").getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        
    }

    /**
     * Método que devuelve true/false si existe o no un Empleado con un NIF concreto en la 
     * lista de empleados obtenida del select del DAO
     * @param NIF
     * @param empleados
     * @return 
     */
    public static boolean existNIF(String NIF,List<Empleado> empleados){
        //Encontrar a través del código
        Optional<Empleado> e_opt = empleados
                .stream()
                .filter(e -> e.getNIF().equals(NIF))
                .findFirst();
        return e_opt.isPresent();
                
    }
    
    public static boolean existNIF2(String NIF,List<Empleado> empleados){
        for(Empleado e: empleados){
            if (e.getNIF().equalsIgnoreCase(NIF))
                return true;
        }
        return false;
    }
    
}
